# P1-BALANCE-02B 执行者交付报告

日期：2026-09-22。代码、Node 自动测试及本报告已交付，模块页面已由 PM 实际检查；真正离线文件打开仍待验收。本报告不改变任务状态，不表示项目已验收。

## 基线、角色与执行边界

- 角色：执行者，实施已派发 P1-BALANCE-02B；实现和本次必要整改均由本执行者完成，未派发或指挥其他执行者。
- 工作树：`D:/WangHaiQing/MyMC/NewMod/CreateNuclearIndustry/.worktrees/p1-balance-02b`。
- 分支：`codex/p1-balance-02b`；实际 HEAD：`41b44cb8b990322076a975981ad6ff1ef94bfbb2`。
- 开工工作树干净。全部交付为未暂存、未提交改动；没有执行 Git 写操作，没有同步 main 或修改 `.git`。
- 未修改 AGENTS.md、核心 docs/计划、Java、游戏配置/存档、构建脚本/依赖、其他工具或范围外模拟器入口。未访问或修改 `C:/Users/lenovo/.codex/worktrees/de8a`。
- 所有 shell 命令都显式指定本工作树或其 `tools/reactor-simulator` 为 workdir。没有启动浏览器、静态服务器、Minecraft、Gradle 或后台进程。
- 本轮人工等待期间推进 02B 已获用户单独授权；本交付不解除 P1-VERIFY-02 人工门，不推进后续主线。

## 必读资料与实际技能应用

实际读取工作树根 AGENTS.md、`docs/project-governance.md`、主活动计划的治理/边界及 02A/02B 适用任务、`2026-09-08-damage-heat-burn-balance-plan.md` 全文，并核对局部控制设计的公式/配置与主策划相关损伤合同。只读主目录 `docs/archive/P1-BALANCE-02A.md` 和存在的 `build/reports/p1/P1-BALANCE-02A.md`，以及本基线正式计算器、参数、相关测试和融毁状态机。

| 技能入口 | 实际应用 | 不适用边界 |
| --- | --- | --- |
| `C:/Users/lenovo/.codex/skills/minecraft-modding/SKILL.md` | 先从 gradle.properties/build.gradle/settings.gradle 核对版本；对照正式服务端裂变公式、控制门控、热量截断与燃耗单位 | 本次仅浏览器/Node 数值工具，不引入 Java、加载器注册、网络包、NBT 或第三方版本示例 |
| `C:/Users/lenovo/.codex/skills/minecraft-testing/SKILL.md` | 将纯公式、模拟结算、DOM 事件替身、模块/单文件一致性与实际浏览器证据分层；端点、中间值、累计与失败原子性使用行为断言 | 不复制 GameTest 模板，不用 Node 替身声称游戏/浏览器人工检查通过，不运行 Gradle 全套测试 |

实际依赖：Minecraft `1.21.1`、Java toolchain `21`、NeoForge `21.1.219`、Create `6.0.10-280`、Ponder `1.0.82`、Flywheel `1.0.6`。本机 Node `v24.18.1`、npm `11.16.0`。依赖、许可证、发布方式保持原合同。

## 实现行为

工具版本从 `1.2.0` 升到 `1.3.0`，规则从 `P1.2-simulator-4` 升到 `P1.2-simulator-5`；场景 schemaVersion 保持 `1`。

1. `fuelColumnDamageHeatMultiplier` 默认 `2.0`，`fuelColumnDamageBurnMultiplier` 默认 `3.0`，对应服务端 reactor 段的同名终点。缺项各自补默认，再联合检查有限性和 `1 < Hmax < Bmax`。显式空串/null/布尔/非数值、不等式非法和非有限输入均拒绝。
2. 以结算前完整度计算 `D = 1 - clamp(integrity, 0, 1)`；热倍率 `1 + (Hmax - 1) * D`，燃耗倍率 `1 + (Bmax - 1) * D`。非有限完整度在直接模拟入口拒绝，有限越界完整度钳制。
3. 只叠乘当 tick 新生裂变热与计划燃耗。超频独立，热量截断不退燃耗；缓存余热与传播算法不再次叠乘。完全插棒、耗尽、末次耗尽和既有热工顺序继续使用原路径。
4. UI 显示“满损伤产热/燃耗倍率”，详情分开显示本 tick 的两个实际倍率，使用结算前值；无结果时标为当前完整度预览。公式文案注明 H/B 的范围及其并非整堆 SU 效率。
5. 非法表单阻止应用、运行、单步、JSON 和 CSV 导出，tick 不推进；有效但尚未应用的修改也不能导出旧配置冒充当前输入。
6. JSON `config` 保存续算参数，`resultMetadata` 保存结果规则、工具版本和实测终点；每个新 tick 的 summary 同时记录元数据。导出工具版本升级不会重标旧结果规则。
7. 旧结果保留来源规则，无版本结果为 `unknown`；未记录的实测终点为 null，补默认只用于续算。旧结果可原样保留历史再导出；旧规则或不同终点续算从现有快照另起记录，保存 `sourceRuleVersion/sourceTick`，不会把旧采样标成新模型实测。导入恢复原摘要、最终快照和列结果，保持暂停。
8. CSV 的 metadata/tick/column 行均保留结果规则与两终点，另用 `replay_` 字段保存续算参数。旧结果未知终点留空，列行导出两个派生倍率。为保证新参数与已有列按表头对齐，使用字段映射生成稀疏行；原先 tick 行冷却字段落到 column_key 等位置的问题随此必要导出适配修正，未改冷却算法。
9. 8 个原场景补齐新版本和参数；新增 4 个一次结算样例。离线单文件内嵌当前模块代码，保留原 HTML/CSS 外壳。
10. 新增和本次相关修改的手写注释使用中文；原 config 的两行相关英文说明改为中文。没有批量翻译未触及代码。

## 极大合法终点溢出整改

PM 指出 Number.MAX_VALUE 域与旧 `finiteNonNegative(Infinity) -> 0` 的冲突后，本执行者先实际复现：固定 5×5×5、孤立满损伤燃料、高度 3，终点为 `Number.MAX_VALUE / 2` 与 `Number.MAX_VALUE`，旧路径输出 `generatedHeat=0`、`plannedBurn=2.4967960206421052e303`、`converged=true`、tick `0→1`。

当前策略：不缩小配置域，不设置新倍率上限；先计算列新生热与计划燃耗的原始乘积，再检查两者及全堆累加值是否有限。任一溢出，在冷却、扣燃料、损伤、传播及 tick 写入之前返回失败结果，包含中文数量/列定位，`converged=false`、`ruleConverged=false`、`running=false`。只附加 simulationFailed 诊断，原快照的列、tick、冷热库存和事故进度不变。UI 停止单步或定时运行，展示错误，不向成功历史追加该次失败。未重写通用 finiteNonNegative 或其他模拟器路径。

行为测试覆盖四种独立路径：

| 条件 | 触发点 |
| --- | --- |
| Hmax=`Number.MAX_VALUE/2`，Bmax=`Number.MAX_VALUE`，单列满损伤 | 列新生裂变热乘积 |
| Hmax=2，Bmax=`Number.MAX_VALUE`，fuelCapacityPerBlock=1000000 | 列计划燃耗乘积 |
| Hmax=4e307，Bmax=5e307，两个隔离满损伤燃料列 | 单列有限，全堆新生热求和溢出 |
| Hmax=2，Bmax=`Number.MAX_VALUE`，fuelCapacityPerBlock=40000，两个隔离满损伤燃料列 | 单列有限，全堆计划燃耗求和溢出 |

证据见 `P1-BALANCE-02B/overflow-evidence.json`。`overflow-full.json` 可直接导入浏览器复现当前拒绝行为。合法极大终点可保存，不代表所有乘法/求和都能用 IEEE-754 有限数完成；溢出必须停止而非静默归零。

## 自动测试与差异检查

| 命令与阶段 | 实际结果 |
| --- | --- |
| 快速 `node --test tests/simulation.test.js tests/damage-balance.test.js tests/report.test.js` | 34/34 通过 |
| 第一次完整 `npm test` | 45/51 通过；6 项失败见下方说明，已整改 |
| 随后完整 `npm test` | 51/51 通过，0 失败、0 取消、0 跳过 |
| 最后同步与新增同规则改终点用例后，`npm test -- --test-name-pattern='文件改用|模块与离线'` | 本意定向验证，但该 npm 脚本的参数位置未起过滤作用，实际完整执行 53/53，通过；0 失败、0 取消、0 跳过。已保留实际输出，没有再重复运行 |
| 工作树根 `git diff --check` | 退出码 0，无错误输出 |

最终 53 项包含：9 项损伤纯行为测试、15 项模块/单文件 DOM 与一致性行为测试、原有 22 项模拟回归、4 项报告回归、1 项场景回放、2 项与本次无关的既有 UI 静态契约测试。新倍率显示不依赖源码字符串匹配：在 Node vm 中执行实际模块/内嵌业务代码，经表单事件、导入、单步、渲染和下载验证。DOM 替身不是实际浏览器。

第一次完整测试的 6 项失败分别为：新增 CSV 测试解析器错误拆开带引号的坐标 `"0,0"`（模块/单文件共 4 项）、新增全堆燃耗溢出夹具容量 30000 未真正触发溢出（改为 40000）、更新空 config 的原场景时引入多余逗号（修正 JSON）。保留业务字段/不等式断言，没有降低正确预期；后续完整 51 与最终 53 项均通过。

原始最终测试输出：`P1-BALANCE-02B/targeted-final-tests.txt`（文件名保留定向运行意图，内容确为完整 53 项）。12 个场景的结果及快照分别在 `scenario-results.csv`、`scenario-final-snapshots.json`；新增版本和终点元数据已记录。检查结束后只编辑 README/报告及把本任务文件换行恢复为原有 CRLF，不改变运行语义。

## 与 02A 的一次结算对照

来源为主目录 `docs/archive/P1-BALANCE-02A.md` 与 `build/reports/p1/P1-BALANCE-02A.md` 的实际历史报告（2026-09-08，基线 `077b88134769b136467f033d538bee7215cacb73`）。两份均已读取；历史自动验收为 225 JUnit、90 required GameTest 与完整构建，本执行者没有重新运行或声称本轮执行这些 Java 测试。

同时只读当前基线正式 `ReactorFissionCalculator`、`ReactorSimulationParameters` 与 `ReactorFissionCalculatorTest`：独立计算两个损伤倍率，再分别乘基础值、高度和控制/反馈强度。02A 的 `customDamageEndpointsReachFormalTickAndReload` 在孤立 `(0,0)`、完整度 0.5、3/5 终点下实际记录 `6 HU/t` 和 216000 最大耐久组件扣 9 点；报告也明确了半损伤归一化 2/3。

本轮 Node 对照统一固定 5×5×5、孤立燃料 `(0,0)`、无控制棒、无反馈、足够燃料与冷却、只结算 1 tick。默认和两组自定义均采 5 个完整度值，共 15 行，完整原值见 `02a-single-settlement-comparison.json`。关键值如下：

| Hmax/Bmax | 完整度 | 归一化热/燃耗 | 热 HU/t | 燃耗等价份/tick |
| --- | ---: | --- | ---: | ---: |
| 2/3 | 1 | 1/1 | 3 | 3/216000 |
| 2/3 | 0.75 | 1.25/1.5 | 3.75 | 4.5/216000 |
| 2/3 | 0.5 | 1.5/2 | 4.5 | 6/216000 |
| 2/3 | 0.25 | 1.75/2.5 | 5.25 | 7.5/216000 |
| 2/3 | 0 | 2/3 | 6 | 9/216000 |
| 1.5/2.5 | 0.5 | 1.25/1.75 | 3.75 | 5.25/216000 |
| 3/5 | 0.5 | 2/3 | 6 | 9/216000 |
| 3/5 | 0 | 3/5 | 9 | 15/216000 |

倍率与热量断言容差 `1e-12`，燃耗率 `1e-15`；1000 tick 累计库存差容差 `1e-11`，汇总消费容差 `1e-12`。充分冷却下完整度保持输入值。216000 倍换算只用于与 02A 同条件样本的计划耐久对照，非对整个游戏库存寿命的等价声明。

## PM 浏览器检查：入口、步骤与预期

模块目录：`D:/WangHaiQing/MyMC/NewMod/CreateNuclearIndustry/.worktrees/p1-balance-02b/tools/reactor-simulator/`；离线文件为该目录 `reactor-simulator-single.html`。

由 PM 在隔离工作树根启动本地服务，例如 `python -m http.server 8000 --bind 127.0.0.1`，模块入口为 `http://127.0.0.1:8000/tools/reactor-simulator/`；真正离线 file:// 文件的实际打开已被 PM 所用浏览器的 URL 安全策略拒绝，因此保留待验收；本轮不得绕过、换浏览器或转托管来执行同一被拒绝动作。检查结束由启动者关闭服务。本执行者未启动任何此类进程。

以下为已交付的通用操作步骤及预期；模块已执行项见下方 PM 反馈。离线浏览器步骤仅保留验收清单，当前策略拒绝后不继续尝试：

1. “导入 JSON”选择 `scenarios/balance-02b-half.json`；导入后保持暂停，步长 tick 下拉设为 `1`，点击“单步”，选择结果网格左上 `[0,0]`。不要点“应用并重置”，它会重建完好初始状态。
2. 半损伤：终点 2/3，本 tick 倍率 1.5/2，总热 4.5 HU/t，燃耗约 `0.000027777778` 份/tick，转换 9 mB/t，tick 1，完整度仍 50%，余热 0。
3. 导入 `balance-02b-full.json` 重复：终点 2/3，倍率 2/3，总热 6 HU/t，燃耗约 `0.000041666667`，转换 12 mB/t，完整度仍 0%，有燃料继续工作。
4. 导入 `balance-02b-custom-half.json` 重复：终点 3/5，半损伤倍率 2/3，其余上述单步数值同满损伤默认样本。可用 `balance-02b-healthy.json` 比较：3 HU/t、倍率 1/1、燃耗约 `0.000013888889`、转换 6 mB/t。
5. 对自定义单步结果导出 JSON、CSV，再导入刚导出的 JSON。终点仍 3/5，tick、剩余燃料、摘要和详情保持。JSON resultMetadata/summary.resultMetadata 与 CSV metadata/tick/column 行记录 3/5 与规则 `P1.2-simulator-5`。CSV 列结果倍率为 2/3。
6. 把终点输入改为 3/2，分别点击应用、运行、单步、JSON 导出、CSV 导出：明确报错，tick/库存不变，不产生新下载。重新导入合法样例可恢复。
7. 如检查极值，导入报告证据目录的 `overflow-full.json`，步长 1、单步或运行：出现“损伤倍率结算数值溢出”及具体列，tick 0、燃料 3、完整度 0%、冷热库存不变，历史不追加成功采样。
8. 如检查旧记录，导入证据目录 `legacy-result-fixture.json`：这是为验证兼容而构造的样例，不是历史实测。页脚保留旧规则 simulator-4；直接导出保持该规则和旧历史，实测终点为空，续算参数 2/3。单步后 tick 7→8、新历史仅 1 行，sourceTick=7、sourceRuleVersion=simulator-4，当前满损伤倍率 2/3，原燃料库存不补满。

实际浏览器状态（来源：PM 在本对话的直接反馈，本执行者未参与操作）：

- 模块页面默认半损伤 1.5/2、满损伤 2/3、自定义终点 3/5 的半损伤 2/3 已由 PM 实际检查通过。
- 模块页面实际 JSON 导出后重新导入、CSV 导出已由 PM 实际检查通过。
- 模块非法 3/2 的应用、运行与 JSON 导出均明确拒绝，tick 未推进，已由 PM 先前反馈确认。
- 真正离线 file:// HTML 打开被浏览器 URL 安全策略拒绝；没有绕过、换浏览器或转为托管去完成同一被拒绝动作。离线文件的实际打开/浏览器观察保留待验收，人工门没有跳过。
- 模块/单文件的 Node vm 运行、DOM 替身与一致性测试仍按自动测试记录；它们不能代替离线浏览器证据。极值浏览器步骤及完整浏览器型号、截图等由 PM 按实际操作补充，本执行者不推定为已完成。


## 残留差异与兼容边界

- 燃料容量/高度：工具每列 `fuelCapacityPerBlock * internalHeight`，默认高度 3 对应 3 等价份，容量与燃耗同比；游戏每列真实单组件耐久，通过小数余数与物品事务结算。工具可变几何，游戏 P1 固定 5×5×5。
- 冷却：网页分数 mB 与固定每可计空气格 1000 mB，未同步游戏整数 mB 量化余数、可配置每格容量或真实 Create capability/管网；初始满冷却剂只是工具实验初态。
- 融毁：工具覆盖分子仍只含接收未冷却传播热的有效燃料；正式实现还计入失效源。工具危险时要求 SCRAM 与有效冷却同时成立才暂停；当前正式 `ReactorMeltdownStateMachine` 在已启动状态下无危险、SCRAM 或有效冷却任一成立即暂停。保持这些既有差异，不宣称全时序一致。
- 未改传播、卡死、维修、事故进度算法，未实现实际物品事务、NBT、区块加载、Ponder、SU 或客户端游戏体验。
- 旧损伤等倍率时长（含历史约 803 ticks）不是本版本结论；本次保存 12 个场景本轮回放原值，不用它们追认完整游戏时序。
- 存档/NBT/注册/网络影响：无；网页 JSON 增加可选元数据与配置字段，旧场景不因缺少新字段被拒绝，非法组合仍拒绝。

## 修改路径与交付物

以下路径均相对隔离工作树，仅包含已授权写集；文件 SHA-256 见 `P1-BALANCE-02B/delivery-manifest.json`。

- `tools/reactor-simulator/README.md`
- `tools/reactor-simulator/reactor-simulator-single.html`
- `tools/reactor-simulator/src/config.js`
- `tools/reactor-simulator/src/simulation.js`
- `tools/reactor-simulator/src/ui.js`
- `tools/reactor-simulator/src/report.js`
- `tools/reactor-simulator/scenarios/balance-02b-custom-half.json`
- `tools/reactor-simulator/scenarios/balance-02b-full.json`
- `tools/reactor-simulator/scenarios/balance-02b-half.json`
- `tools/reactor-simulator/scenarios/balance-02b-healthy.json`
- `tools/reactor-simulator/scenarios/cold-end-limited.json`
- `tools/reactor-simulator/scenarios/control-rod-isolation.json`
- `tools/reactor-simulator/scenarios/empty-isolation.json`
- `tools/reactor-simulator/scenarios/hot-end-limited.json`
- `tools/reactor-simulator/scenarios/p1-control-05-fcf.json`
- `tools/reactor-simulator/scenarios/p1-default-5x5x5.json`
- `tools/reactor-simulator/scenarios/propagation-paused-meltdown.json`
- `tools/reactor-simulator/scenarios/safe-overclock.json`
- `tools/reactor-simulator/tests/scenario.test.js`
- `tools/reactor-simulator/tests/simulation.test.js`
- `tools/reactor-simulator/tests/ui.test.js`
- `tools/reactor-simulator/tests/damage-balance.test.js`
- `tools/reactor-simulator/tests/damage-ui.test.js`
- `tools/reactor-simulator/tests/ui-harness.js`

报告及原始证据位于 `build/reports/p1/`（build 被 Git 忽略，需 PM 按交付路径读取）：

- `P1-BALANCE-02B.md`：本报告。
- `P1-BALANCE-02B/targeted-final-tests.txt`：最终实际 53 项完整 Node 输出。
- `P1-BALANCE-02B/diff-check.txt`：成功检查无错误输出，退出码 0 记录在命令输出及本报告。
- `P1-BALANCE-02B/scenario-results.csv`、`scenario-final-snapshots.json`：12 场景当前规则回放结果。
- `P1-BALANCE-02B/02a-single-settlement-comparison.json`：15 个默认/自定义一次结算对照值及历史来源说明。
- `P1-BALANCE-02B/overflow-evidence.json`、`overflow-full.json`：整改前实际复现值、当前拒绝结果和浏览器样例。
- `P1-BALANCE-02B/custom-half-t1.json`、`custom-half-t1.csv`：当前规则 3/5 半损伤一次结算导出样本。
- `P1-BALANCE-02B/legacy-result-fixture.json`：合成旧结果兼容检查样例，明确非历史实测。
- `P1-BALANCE-02B/delivery-manifest.json`：24 个工具交付文件路径及哈希。

没有范围外实现文件，没有未经授权的 Git 写操作。执行者到此交付并停止；待验收的离线文件实际打开、其余真实浏览器检查及最终审查由项目经理处理，执行者不自我验收、不改变任务状态。
