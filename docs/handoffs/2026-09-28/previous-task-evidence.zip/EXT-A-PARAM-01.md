# EXT-A-PARAM-01：D-03e 四项参数静态复核

日期：2026-09-24。执行者交付，等待 PM 验收；不批准候选参数、不改变任务状态或玩法。

## 基线与范围

- 实际 HEAD：`7193cf27c0ba141f64cd58b5a722869257537e0f`，分支 `main`。复核对象为 `docs/superpowers/plans/2026-09-24-first-production-cost-draft.md` 工作区新增第 3.1 节，不是仅复核 HEAD 中的旧内容。
- 已读根 `AGENTS.md`、`docs/project-governance.md`、活动 P1 计划 `docs/superpowers/plans/2026-08-18-agent-developer-execution-plan.md`、第 3.1 节完整任务合同及 EXT-A-DEPS-01 归档和相关证据。P1 客户端人工门不变。
- 实际读取并应用 `C:/Users/lenovo/.codex/skills/minecraft-modding/SKILL.md`：核对版本、配方类型、标签输入和设备分工。实际读取并应用 `C:/Users/lenovo/.codex/skills/minecraft-testing/SKILL.md`：区分静态可表达性、真实配方/事务测试与客户端证据，不套用其他版本 GameTest 示例。
- `gradle.properties`、`build.gradle`、`settings.gradle` 与已有依赖清单相符：Minecraft 1.21.1、Java 工具链 21、NeoForge 21.1.219、Create 6.0.10-280、Ponder 1.0.82、Flywheel 1.0.6。依赖事实复用已验收审计，本次未重新计算 JAR 哈希或重新反汇编。
- 开工时已有成本草案修改；过程中还观察到 `docs/recipes.md`、`docs/superpowers/plans/2026-09-22-first-release-extension-preparation-plan.md`、`docs/superpowers/plans/2026-09-24-production-process-proposal.md` 修改，属于已告知的 PM 并行文档工作，全部保留。
- 本次唯一写入文件为本报告。无功能、测试、资源、脚本、构建、配置或 Git 写操作；无派发他人。

## 结论与证据

结论：四项候选在锁定 Create 的现有配方机制中有静态表达依据；数量与措辞复核通过，未发现本范围内必须改正文档的实质错误。这里的“通过”仅指执行者静态检查结果，最终验收由 PM 决定。

下列证据文件均位于 `build/reports/extension/EXT-A-DEPS-01/`；它们是历史审计证据，本次只读抽查，未冒充新运行结果。

| 检查项 | 结果及依据 |
| :--- | :--- |
| 青金石制粉 1:1 | 静态通过。单个 `c:gems/lapis` 标签输入、单个固定 `create_nuclear_industry:lapis_dust` 输出可用粉碎配方表达，不需要概率副产物。既有报告第 5 节确认标签含原版青金石；第 6 节及 `javap-CrushingWheelControllerBlockEntity.txt:959` 的 `findRecipe()` 确认先 CRUSHING 后 MILLING。粉碎专用制粉与磨石染料分工有依据，但粉末注册、标签和新配方仍待实现，不能称当前已可生产。 |
| 粉碎 `processing_time=100` | 静态通过。`selected-create-recipes.json:102` 的原生青金石磨石配方确为 100；仅借用参数尺度，不复制蓝染料产物和概率。`javap-CrushingWheelControllerBlockEntity.txt:1083` 读取配方时长到 remainingTime，约 239–266 行显示按设备处理量扣减，不能把粉碎参数直接解释为固定 5 秒或 100 秒。 |
| 最低热级 `heated` | 静态通过。`selected-create-recipes.json:18` 的黄铜搅拌配方使用 `heat_requirement: heated`；`javap-BasinRecipe.txt:98` 调用热级判定。`javap-HeatCondition.txt` 的 `testBlazeBurner()` 明确排除 NONE、SMOULDERING，接受普通燃烧及 SEETHING。故普通加热可满足、无热/阴燃不满足、超级加热也可加工，与草案一致。无需给本候选另设超级加热配方或奖励。 |
| 搅拌 `processing_time=100` | 静态通过。`javap-MechanicalMixerBlockEntity.txt:292` 起读取非零配方时长并除以 100，再结合转速、log2、取整与下限计算处理段；100 对应基准倍率 1。该处理段没有按热级另加速度倍率的分支。配方时长不是完整工序墙钟耗时，设备升降、供料出料仍须另计。 |
| 最低转速与应力 | 静态措辞通过。第 3.1 节明确继承玩家 Create 配置，不新增转速/应力覆写或设备补丁。`javap-MechanicalMixerBlockEntity.txt:246` 仍调用原生 `isSpeedRequirementFulfilled()`；不能把“本模组不新增门槛”解释为“原生设备无门槛”。64/128/256 RPM 只是未来对照样本，并未承诺每档都能运行。本次未核定原生阈值数值。 |

## 数量复算

按已批准的每批三粉各 1 份、水 1000 mB、产物 1000 mB，批数为 `ceil(堆内目标 / 1000)`。制粉 1:2 时，青金石为 `ceil(批数 / 2)`，余粉为 `2 × 青金石数 - 批数`。

| 堆内目标 mB | 搅拌批数 | 1:1 青金石 | 1:2 青金石 | 1:2 余青金石粉 | 红石粉、荧石粉各自份数 | 用水 mB |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| 3000 | 3 | 3 | 2 | 1 | 3 | 3000 |
| 9000 | 9 | 9 | 5 | 1 | 9 | 9000 |
| 24000 | 24 | 24 | 12 | 0 | 24 | 24000 |

三行均与草案一致；1:2 只改变青金石投料及余粉，不改变搅拌批数、红石、荧石和水。不是矿石掉落折算。外部回路持液另计，也不形成满罐启动要求；非整批需求仍须向上取整并保留余量。本报告不选择 1:1 或 1:2 的玩法方案。

## 缺证、未运行与交回

- 缺证：候选新配方的解析/实际匹配、标签替代及错误形态拒绝、粉碎与磨石实机分工、1000 mB 输入扣除及输出容纳、无热/阴燃/普通/超级热级实际表现、断动力/断热、保存恢复和配方重载均未验证。超级加热不增产/不加速有当前静态机制支持，实际产出及时间仍须实现后验证。
- 未验证实际 Create 配置下各转速能否运行、首批耗时及连续吞吐，未完成平衡或真实第三方兼容验收。不得将第 3 节盆体单段容量说明等同于运行事务通过。
- 本次只运行只读 `Get-Content`、`rg`、目录/文件检查、`git rev-parse HEAD`、`git status --short --branch`、`git diff --check` 等核查。`git diff --check` 无空白错误，仅提示 PM 文档未来可能发生 LF/CRLF 转换；该命令不覆盖忽略的 build 报告，因此报告另行回读核对。
- 按本任务更窄合同，未运行 Gradle、JUnit、GameTest、客户端、服务端、数据生成或脚本；未创建脚本，不重做整链审计。纯报告无运行行为、NBT、注册或网络兼容变化；代码中文注释检查不适用。
- 需改项：本次限定范围未发现必改项。后续参数批准、实现派发和运行验收均交 PM 处理；执行者停止于报告交付，等待验收。
