# EXT-A-DEPS-01 首发生产依赖与标签兼容只读审计

交付日期：2026-09-24。执行者阶段交付，等待 PM 验收。本文不改变任务卡状态，不批准候选玩法或成本，不构成生存可达性验收。

## 1. 首要决策门与结论

**首批燃料加工的设备分工尚不能直接转为实现合同。** 锁定 Create 已有煤、木炭磨石制染料和黑曜石粉碎配方；文档中的制粉路线可能与其同输入竞争。合金钢板又同时进入密封环、钢网和包壳管的压片候选。烧结炉首次使用的非核热源尚未明确。这些不是补填数量即可解决的缺口，依赖相应选择的实现应停止派发。

**首台三种设备在已写明的材料关系中未发现必然的自身产物循环，但尚不能证明可启动。** 注册、材料来源、专用设备运行及部分工序合同均缺失；若把烧结或上游材料限定为核热，才会形成“首批燃料→核堆→热源→首批燃料”的循环。当前证据只支持条件风险，不能宣称已经存在这种运行时死锁。

**首台反应堆还有独立来源缺口：** `reactor_fuel_rod` 已注册、参与结构且有掉落，但配方表未给制造来源；它不能自动等同于 `fresh_fuel_rod` 或 `fresh_fuel_assembly`。首发屏蔽装配台与 P3 专用机械臂的阶段关系也需澄清；已批准手动转运，因此这不是人工首批生产必然卡死的证据，而是首发自动化合同缺口。

项目经理要求本轮立即收敛后，不再扩展取证。以下区分已观察事实、文档推导与未验证；未决处停止依赖推导，未自行选择方案。

## 2. 基线、权限与方法

- 工作目录：`D:/WangHaiQing/MyMC/NewMod/CreateNuclearIndustry`。
- 需求基线：`4f03d73`；任务卡提交：`ded6ff6`。
- 接单实际 HEAD：`ded6ff663d03970dda50d589236c96f56b8fd33a`；首次 `git status --short` 无输出。
- 收束前实际 HEAD：`e0eee1a0d7b3a75d12e46203b5961a59067ac13c`。项目经理确认这是 PM 成本草案与派发记录提交。收束检查 `git diff ded6ff6 --name-only -- src build.gradle gradle.properties settings.gradle` 无输出。
- 收束检查 `git status --short --branch` 为 `## main...origin/main [ahead 7]`；工作区及暂存区名称差异均为空。原始输出见证据目录 `git-progress.txt`；交付时状态另见 `git-final.txt`。
- PM 成本草案是未批准候选。本审计未采用其数值、未核算成本。文档并行变更不由本执行者覆盖或撤销；需求/源码证据快照固定读取 `ded6ff6`。
- 完整读取本任务卡；读取并应用 `AGENTS.md`、治理协议、活动 P1 计划、首发扩展准备计划，以及主策划、内容清单、配方表和路线图。以任务卡的更窄写集与不运行游戏要求为准，不执行 P1 实现卡的通用构建/游戏步骤。
- 实际应用 `C:/Users/lenovo/.codex/skills/minecraft-modding/SKILL.md`：版本核对、注册身份与素材分离、1.21.1 单数 `recipe` / `tags/item` 路径、Create 配方类型及服务端库存边界。
- 实际应用 `C:/Users/lenovo/.codex/skills/minecraft-testing/SKILL.md`：资源静态证据、真实设备匹配、事务与人工流程分层；不将字节码或 JSON 存在视作 GameTest/人工通过。
- 未运行 Gradle、客户端、服务端、GameTest 或其他测试；未下载/安装模组、修改配置、派发他人或执行 Git 写操作。执行了只读 Git/rg、Python ZIP/JSON 检查、JDK `javap -c -p` 和 `java -version`；所有落盘均在允许报告与证据目录。

### 2.1 锁定版本

`gradle.properties:6–14`、`build.gradle:13,20–21,85–94` 锁定 Minecraft 1.21.1、Java 21、NeoForge 21.1.219、Create 6.0.10-280、Ponder 1.0.82、Flywheel 1.0.6。实际用于反汇编的 `C:/Program Files/Java/jdk-21/bin/java.exe` 报告 21.0.7；未因此推定所有运行配置都使用该 JVM。

| 本机依赖 | SHA-256 |
|---|---|
| `create-1.21.1-6.0.10-280-slim.jar` | `f0652bee27460f2d26a748f537cb5d687981441378d3a526d17ffaab5a1072bb` |
| `neoforge-21.1.219-universal.jar` | `a062142f38543701e3d4da385f19e8dd9d76d19625c204e9c0aca22ad491b4fd` |
| `ponder-neoforge-1.0.82+mc1.21.1.jar` | `0cf4611ad853042b689ac386184c5bbe02950efcffddb49e5f604e82baddb0dc` |
| `flywheel-neoforge-1.21.1-1.0.6.jar` | `31dda15c205eb596d3b3449ef03f6af7363a6cd35b3da4bfe916b304f9e5337e` |

完整绝对路径见 `EXT-A-DEPS-01/dependency-manifest.json`。以下所有 JAR 条目均指这组锁定依赖，不使用其他版本示例推断。

### 2.2 证据索引

证据根目录：`D:/WangHaiQing/MyMC/NewMod/CreateNuclearIndustry/build/reports/extension/EXT-A-DEPS-01/`。

| 简称 | 证据及定位方式 |
|---|---|
| B | `baseline-source-evidence.txt`：`git show ded6ff6:<path>` 的文档、构建文件、注册源码及资源契约测试，按原文件行号编号；本文 `R`、`C` 引用均可在此复核 |
| R / C | `docs/recipes.md` / `docs/content-catalog.md`，采用 `ded6ff6` 行号 |
| S | `source-inventory.txt`：源码和资源文件清单；用于区分素材占位与实际注册/配方 |
| T | `create-tags.json`、`neoforge-tags.json`：以原 JAR 条目为键的 JSON 内容；`tag-matrix.md` 展开 57 个具体标签及直接父引用 |
| J | `create-recipes.json`、`selected-create-recipes.json`：以原 JAR 条目为键，保留配方内容与条件；仅选中条目用于本文结论，未作穷尽第三方审计 |
| E | `create-entries.txt`、`neoforge-entries.txt`：完整 ZIP 条目名，支持目标条目存在/缺失检查 |
| V | `javap-*.txt`：锁定 Create 类的反汇编，引用类名、方法名和关键行；不是运行结果 |

首次查询不存在的顶层 `SplashingType` 返回错误，保留于 `javap-SplashingType.txt`；随后通过 JAR 条目定位真正的 `AllFanProcessingTypes$SplashingType` 并成功读取。错误文件不是正面证据。

## 3. 当前实现边界

正式物品注册只有 `fresh_fuel_assembly`、`cooled_spent_fuel_assembly`、`control_rod`、`steel_plate`、`compound_coolant_bucket`（`ModItems.java:24–50`）。正式冷/热冷却剂及各自流动态注册见 `ModFluids.java:46–76`。反应堆八种方块及对应 BlockItem 见 `P1Blocks.java:31–61`，另保留样例外壳与 P0 探针。

目前项目物品通用标签仅发现 `data/c/tags/item/plates/steel.json`；配方目录仅有 `p0_probe_slider_block.json`、`p0_probe_goggle_block.json`。未发现生产配方提供器或专用生产机器注册。铅/锡/铀等现有 PNG 不是已注册物品或矿物获取路径。`src/generated/resources` 本次枚举未返回文件；未用旧 build 产物代替源码。

`P1DataContractTest.java:125–149` 仍明确拒绝包含钢板、冷却剂、燃料组件等的 P1 生存配方。未来批准生产实现时，任务卡需一并处理这个历史边界测试，保留禁止普通冷热互转、污染冷却剂/净化器的有效约束；不能直接把整项测试删掉。本次未修改或运行它。

## 4. 最小生产节点表

表中本模组 ID 均省略固定前缀 `create_nuclear_industry:`。**“未注册”表示仅有文档身份，不是已实现内容。** 通用形态的具体标签见第 5 节；专用核材料的具体标签名若文档尚未确定，直接标缺项，不自造名称。数量、概率、时间、热级、应力均不推定。

### 4.1 材料、零件和冷却剂

| 节点 / 正式或文档 ID | 状态、阶段 | 来源与加工设备 / 前置 | 标签、副产物与证据 |
|---|---|---|---|
| 铅矿/深层矿/粗铅/粗矿块：`lead_ore`、`deepslate_lead_ore`、`raw_lead`、`raw_lead_block` | 未注册；勘探 | 项目矿物来源尚未实现；矿石掉落/生成待实现，粗矿压缩关系未细化 | `c:ores/lead`、`c:raw_materials/lead`、`c:storage_blocks/raw_lead`；C53,133,140；B/S |
| 锡对应四形态：`tin_ore`、`deepslate_tin_ore`、`raw_tin`、`raw_tin_block` | 未注册；勘探 | 同上 | 对应 `/tin`、`/raw_tin`；C54,134；B/S |
| 铀对应四形态：`uranium_ore`、`deepslate_uranium_ore`、`raw_uranium`、`raw_uranium_block` | 未注册；勘探 | 同上；不得补造铀锭前置 | 对应 `/uranium`、`/raw_uranium`；C55–61,135–140 |
| `create:crushed_raw_lead`、`create:crushed_raw_tin`、`create:crushed_raw_uranium` | Create 已有身份；上游来源缺 | 粉碎轮可读取三种矿石/粗矿/粗矿块的具体标签；已有条件配方 | 已进 `create:crushed_raw_materials`；缺 `c:crushed_raw_materials/*`；J/V/T；详见第 6 节 |
| `lead_nugget`、`lead_ingot`、`lead_plate`；`tin_nugget`、`tin_ingot`、`tin_plate` | 未注册；勘探/燃料制造 | 粉碎粗矿洗涤→粒；粒或粗矿熔炼→锭；锭压片→板 | 对应 `c:nuggets/*`、`c:ingots/*`、`c:plates/*`；洗涤石料副产未落配方；R160–175 |
| `lead_dust`、`tin_dust`、`lead_rod`、`lead_block`、`tin_block` | 未注册；已登记形态 | 首套主线不依赖全部形态；R5–8 未逐项给制备路线 | 对应粉/杆/储存块标签；C53–54,133–134；只记缺项，不扩展为本轮实现要求 |
| `coal_dust`、`charcoal_dust` | 未注册；钢材前置 | 煤/木炭→粉碎轮或磨石；磨石已有染料竞争 | `c:dusts/coal`、`c:dusts/charcoal`；R192,196；J `milling/coal.json`、`charcoal.json` |
| `quartz_dust` | 未注册；耐火材料前置 | 石英→粉碎轮或磨石 | 原料可复用 `c:gems/quartz`；输出 `c:dusts/quartz` 待补；R197 |
| `obsidian_dust` / `create:powdered_obsidian` | 前者仅登记；后者已存在 | 黑曜石粉碎；首发材料阶段，服务坚固板/耐热玻璃 | `c:dusts/obsidian` 已含 Create 产物；已有返还黑曜石的概率输出；不能再默认添加同输入配方；R198,207；C78 |
| `glass_dust` | 未注册；封存前 | 玻璃→粉碎轮；不是首台三种机器的共同前置 | `c:dusts/glass` 待补；R199,208 |
| `steel_ingot`、`steel_plate` | 钢板已注册但无生存来源；钢锭未注册 | 铁锭+煤粉或木炭粉→加热搅拌→钢锭→压片钢板 | `c:ingots/iron`、两种碳粉细标签、`c:ingots/steel`、`c:plates/steel`；无副产；R192–193；B |
| `steel_pipe_blank`、合金钢轴 | 管坯未注册；“轴”与 `steel_rod` 的身份映射未明确 | 钢锭→切石工序；同输入多输出需要选择 | 管坯具体标签未定；`steel_rod` 对应 `c:rods/steel`，不能自行据此创设 `steel_shaft`；R194,221；C67,71 |
| `tin_wire`、`solder_ingot` | 未注册；燃料制造 | 锡锭→切石/拉制为锡条；锡+铜→加热搅拌为焊料 | `c:wires/tin`、`c:ingots/solder`；焊料本模组别名未明确；R174–175；C54,69 |
| `seal_ring`、`steel_mesh`、`fuel_cladding_tube` | 未注册；燃料制造 | 同一钢板分别压片或切石；直接压片有竞争 | 精确零件标签待定；无副产；R216,218,262；C70,72,98 |
| `steel_grate`、`steel_frame`、`pressure_fitting`、`maintenance_seal` | 未注册；格架为首批组件必需 | 钢网+钢板→格架；钢板+轴→框架；钢板+焊料→接头；钢板+焊料+干海带→维护密封件 | 机械装配/机械手/序列装配需明确类型；R217,219–220,227 |
| `heavy_bearing` | 未注册；配方表标“商用机组”，却是首台离心机前置 | 坚固板+钢锭+精密构件→序列装配 | Create 坚固板、精密构件路线可复用；无已知核热输入；R228,321；C75 |
| `industrial_sensor` | 未注册；燃料制造且被多设备先用 | 铁片+锡条+红石+电子管→序列装配 | 铁片 `c:plates/iron`，锡条 `c:wires/tin`，红石 `c:dusts/redstone`；本体不等于后置仪表功能；R225,321–323 |
| `radiation_sensor` | 未注册；R标勘探但依赖上行“燃料制造”传感器 | 铅板+工业传感器+电子管→序列装配 | 首台装配台必需；作为材料可提前提供，但不据此实现 P3 辐射系统；R226,323；C73 |
| `industrial_ceramic`、`refractory_brick` | 未注册；耐火砖为首台烧结炉前置 | 石英+黏土→工业陶瓷；砖块+黏土+石英粉→耐火砖；文档为加热搅拌/烧制 | 公共专用标签名未定；多输入不能不经澄清直接映射为单输入熔炉配方；R200,202,322 |
| `insulation_plate`、`neutron_absorbing_ceramic` | 未注册；后续设备/控制棒 | 耐火砖+陶瓷→压片隔热板；陶瓷+铅粒+红石→吸收陶瓷 | 双输入隔热板不能直接用单输入 `create:pressing`；R203–204；精确标签未定 |
| `reinforced_steel_plate`、`heat_resistant_glass`、`shielded_glass` | 未注册；运行设备材料 | 钢板+坚固板+精密构件→强化板；黑曜石粉+石英粉+玻璃→耐热玻璃；玻璃+铅板→屏蔽玻璃 | `c:plates/reinforced_steel` 独立于普通钢板；R195,205,207；不让全套后期设备成为首批燃料前置 |
| `shielding_concrete`、铅屏蔽构件 | 未注册；后续堆体/封存结构 | 混凝土+铅粒或屏蔽尾矿→搅拌；铅板→压片/切石构件 | 混凝土具体接受范围、铅屏蔽构件正式 ID 未明确；R164,206；不自造注册名 |
| `lapis_dust` | 未注册；冷却剂前置 | `c:gems/lapis`→粉碎轮；磨石原染料路线保留 | `c:dusts/lapis` 加入 `c:dusts`；固定本模组产物；D-02/02a、R95–96,236 |
| `compound_coolant`、`compound_coolant_bucket` | 已注册；制造配方缺 | 青金石粉+红石粉+原版荧石粉+水→加热搅拌盆 | 三粉必须分别读 `c:dusts/lapis`、`redstone`、`glowstone`；水可用已存在的流体 `c:water`；液量/热级未定；R237；B |
| `hot_compound_coolant` | 已注册；运行状态 | 既有反应堆冷转热；后续核换热器回冷 | 不是普通配方互转；热态无普通桶；R238–241；B |

### 4.2 三台设备、燃料和基础封存边界

| 节点 / ID | 当前状态、前置与设备 | 输出/副产/停止点 | 证据 |
|---|---|---|---|
| 富集离心机 `enrichment_centrifuge` | 未注册；铜外壳+重型轴承+精密构件+工业传感器→序列装配 | 制造输入不含离心机产物；稳定转速/效率及进度合同未实现、数值未定 | R321；C166；B/S |
| 燃料烧结炉 `fuel_sintering_furnace` | 未注册；耐火砖+钢板+烈焰人燃烧室+工业传感器→机械装配 | 制造不依赖烧结芯块；烈焰人作为制造材料不等于已有外部供热运行合同；首次热源待定 | R146,322；C167；B/S |
| 屏蔽装配台 `shielded_assembly_station` | 未注册；铅板+钢板+机械手+辐射传感器→机械装配 | 制造输入不需先使用该台；普通机械手 `create:deployer` 与动力机械臂 `create:mechanical_arm` 不是同一设备 | R147,323；C168；B/S |
| 铀精矿 `uranium_concentrate`、尾矿 `uranium_tailings` | 均未注册；粉碎粗铀经鼓风洗涤 | 精矿为主线；尾矿必须保留，不能用普通铀粉/铀粒代替；洗涤“+水”是否计量消耗待明确 | R181–186；V `SplashingRecipe`、`AllFanProcessingTypes$SplashingType` |
| `uranium_tailings_brick`、`shielded_tailings_block` | 未注册；尾矿压砖→与铅板在装配台屏蔽 | 不是首批洗矿必须先建好的设备；须能暂存尾矿，输出满不得吞掉副产物 | R183–186；C136 |
| 铀料浆 `uranium_slurry` | 未注册；精矿+水→加热搅拌 | 流体；提供桶或密封容器的原则已有，精确容器身份/事务待定，人工转运必须有可用路径 | R251；C36；不得猜造桶 ID |
| `low_enriched_uranium_dust`、`depleted_uranium_dust` | 未注册；料浆→离心机 | 同时输出低浓缩粉、贫化粉、可回用工艺水；专用标签名未定；不得加入普通 `c:dusts/uranium` | R252；C96；R98 |
| `green_fuel_pellet`、`sintered_fuel_pellet` | 未注册；低浓缩粉→压片→专用烧结 | 首次非核供热/批量待明确；禁止鼓风加热替代专用烧结 | R260–261 |
| `fresh_fuel_rod` | 未注册；烧结芯块+包壳+焊料→屏蔽装配台 | 保留芯块进入包壳工序，不是结构柱方块 | R263；C99 |
| `fresh_fuel_assembly` | 已注册，无生产配方；燃料棒+格架+工业传感器→序列装配/屏蔽装配台 | 两种设备的职责尚需明确；必须保留棒入格架，沿用既有耐久和端口所有权 | R264–270；ModItems24–29 |
| `reactor_fuel_rod` | 已注册方块、BlockItem；结构必需；制造来源缺项 | R第12节没有制造行。不能用新燃料棒/组件消耗方式填空 | P1Blocks42,58–59；C151；R330–346；S |
| `reactor_casing`、`reactor_window`、`reactor_cold_port`、`reactor_hot_port`、`reactor_instrument_port`、`reactor_refueling_port` | 已注册，无生存配方 | 依赖屏蔽混凝土/铅板/钢板、玻璃、接头/密封、传感器、电子管/机械手等；来源关系可依R补实现 | R334–338；P1Blocks31–59 |
| `control_rod`、`control_rod_drive` | 已注册，无生存配方 | 钢轴+吸收陶瓷+黄铜片→组件→机械活塞/活塞杆/精密构件→驱动器；轴身份待澄清 | R339–346；B |
| `cooled_spent_fuel_assembly` | 已注册，运行耗尽终态；不是普通加工原料替身 | 后续封存接收现有身份；不引入热乏燃料、乏燃料池为首发前置 | R268,280–283；B |
| `vitrification_medium`、`encapsulated_spent_fuel`、`lead_shielding_cask`、`sealed_spent_fuel_cask`、`dry_storage_rack` | 均未注册；运行闭环之后、完整首发之前 | 玻璃碎料+石英粉+黏土制基材→装配台灌封→铅桶封装→贮存；铅桶用铅板/钢板/密封环，架用屏蔽混凝土/钢框架 | R208,281–283,310–311；不细化后期再处理 |

贫化粉的后续配重/复合屏蔽用途（R253–254）不应成为第一次离心出料的强制前置；本轮仅要求副产物有保留与暂存路径，不自行添加消除或回收配方。

## 5. 标签兼容矩阵

`T` 保留具体 JSON 值和父引用；本文箭头表示应当显式加入父标签，**不是路径自动继承**。JAR 中缺条目只说明锁定两依赖未提供，不等于生态中从未存在。

### 5.1 基础粉末、钢材与冷却剂

| 物品/用途 | 完整具体标签与父关系 | 锁定版本事实 / 缺口 |
|---|---|---|
| 青金石原料 | `c:gems/lapis` → `c:gems` | NeoForge 提供 `minecraft:lapis_lazuli`，并有可选旧 `#forge:gems/lapis`；父已有引用 |
| 青金石粉 | `c:dusts/lapis` → `c:dusts` | 两 JAR 和项目均无该子标签；项目已批准补充，不能称加载器内置 |
| 红石粉 | `c:dusts/redstone` → `c:dusts` | NeoForge 提供 `minecraft:redstone` 与可选旧标签；父关系存在 |
| 荧石粉 | `c:dusts/glowstone` → `c:dusts` | NeoForge 提供 `minecraft:glowstone_dust` 与可选旧标签；父关系存在，不复制物品 |
| 石英/石英粉 | `c:gems/quartz` → `c:gems`；`c:dusts/quartz` → `c:dusts` | 宝石标签内置；粉末子标签及父接入待项目补充 |
| 煤粉、木炭粉 | `c:dusts/coal`、`c:dusts/charcoal` → `c:dusts` | 两子标签未提供；不能以黑/灰染料冒充；分别输出何种粉末须保持原料语义 |
| 玻璃碎料 | `c:dusts/glass` → `c:dusts` | 子标签未提供；玻璃输入可查 `c:glass_blocks/colorless` → `c:glass_blocks`，彩色/遮光等接受范围未冻结，不自动扩大 |
| 黑曜石粉 | `c:dusts/obsidian` → `c:dusts` | Create 子标签已有 `create:powdered_obsidian`；**父 `c:dusts` 未引用此子标签**，项目当前也未补；本模组 `obsidian_dust` 仍未注册 |
| 普通钢锭 | `c:ingots/steel` → `c:ingots` | 子标签未提供；父存在但不含钢；`steel_ingot` 待实现 |
| 普通钢板 | `c:plates/steel` → `c:plates` | 项目子标签 `replace:false`，含正式 `steel_plate`；Create 父标签只直接列自身板材，**未包含本项目钢板或钢子标签** |
| 钢杆、钢储存块 | `c:rods/steel` → `c:rods`；`c:storage_blocks/steel` → `c:storage_blocks` | 子标签及成员未实现；“合金钢轴”是否映射 `steel_rod` 未冻结 |
| 强化钢板 | `c:plates/reinforced_steel` → `c:plates` | 子标签未实现；不能并入 `c:plates/steel` 冒充普通板 |
| 焊料 | `c:ingots/solder` → `c:ingots` | 子标签未提供；项目公共别名的完整名称尚缺，第三方等价语义未验证 |
| 搅拌用铁、铜 | `c:ingots/iron`、`c:ingots/copper` → `c:ingots` | NeoForge 已有原版成员和父关系 |
| 水 | 流体 `c:water` | NeoForge `data/c/tags/fluid/water.json` 含源/流动水；不是物品标签 `c:buckets/water`，不能把水桶当液量字段 |
| 冷/热复合冷却剂、料浆 | 适用流体专用标签名称待明确 | 现有冷/热流体身份可复用，未发现项目对应流体标签；配方与能力的接受范围不能仅凭显示名放宽 |

既有 NeoForge `c:dusts` 只有红石/荧石子标签及可选 `#forge:dusts`。可选旧桥接的存在不授权新配方回退使用 `forge:*`；本项目按 `c:*` 追加，禁止 `replace:true`。具体粉末配方不得读宽泛 `c:dusts`。第三方只有实际声明同标签且语义等价才属于候选替代，尚无真实第三方加载证据。

### 5.2 三种矿物粗加工品及形态

下面列全具体名字；这些子标签在锁定 NeoForge/Create JAR 中均未发现，项目也尚未提供，**Create 粉碎产物身份除外**。父标签是否已有资源及直接引用详见 `tag-matrix.md`。

| 形态 | 铅 | 锡 | 铀 | 父/边界 |
|---|---|---|---|---|
| 矿石 | `c:ores/lead` | `c:ores/tin` | `c:ores/uranium` | 应显式汇入 `c:ores`；Create 已有配方条件会读取这些子标签 |
| 粗矿 | `c:raw_materials/lead` | `c:raw_materials/tin` | `c:raw_materials/uranium` | 应汇入 `c:raw_materials` |
| 粗矿块 | `c:storage_blocks/raw_lead` | `c:storage_blocks/raw_tin` | `c:storage_blocks/raw_uranium` | 应汇入 `c:storage_blocks` |
| 粉碎粗矿 | `c:crushed_raw_materials/lead` | `c:crushed_raw_materials/tin` | `c:crushed_raw_materials/uranium` | 项目拟补子标签，分别含对应 `create:crushed_raw_*`；`create:crushed_raw_materials` 已直接包含三物品；`c:crushed_raw_materials` 父资源亦缺，若提供须显式连接 |
| 锭 | `c:ingots/lead` | `c:ingots/tin` | `c:ingots/uranium` | 前两者待补至 `c:ingots`；铀金属形态暂缓，不要求建空物品 |
| 粒 | `c:nuggets/lead` | `c:nuggets/tin` | `c:nuggets/uranium` | 前两者待补至 `c:nuggets`；铀粒暂缓 |
| 普通粉 | `c:dusts/lead` | `c:dusts/tin` | `c:dusts/uranium` | 铅/锡已登记但制备缺项；不把精矿/低浓缩/贫化粉填进铀普通粉标签 |
| 板 | `c:plates/lead` | `c:plates/tin` | `c:plates/uranium` | 铅/锡待补至 `c:plates`；铀板暂缓 |
| 杆/线 | `c:rods/lead` | `c:wires/tin` | `c:rods/uranium` | 铅杆/锡条有文档 ID；相应父 `c:rods` / `c:wires` 须显式接入，后者两 JAR 未提供；铀杆暂缓 |
| 金属储存块 | `c:storage_blocks/lead` | `c:storage_blocks/tin` | `c:storage_blocks/uranium` | 前两者有文档身份；铀块暂缓，不引入燃料链 |

工业陶瓷、耐火砖、隔热板、中子吸收陶瓷及核专用材料按 R85,98 使用本模组公共/专用标签，但没有给出全部正式标签名。本轮把它们记为命名与输入合同缺项，不造“公认通用”标签。

## 6. Create 复用、竞争与设备表达

### 6.1 可以确认的复用事实

1. **三种粉碎粗矿已经注册。** `AllItems` 的静态初始化无条件调用 `compatCrushedOre(CommonMetal.TIN/LEAD/URANIUM)`（V `javap-AllItems.txt:1341–1356`），辅助方法调用 `.register()`（230–250）。`TagDependentIngredientItem.shouldHide()` 根据矿石标签是否为空决定隐藏；“隐藏”不等于未注册。三者亦在 `data/create/tags/item/crushed_raw_materials.json` 中。
2. **三矿各有三类已有条件配方。** JAR `data/create/recipe/crushing/{lead,tin,uranium}_ore.json`、`raw_{lead,tin,uranium}.json`、`raw_{lead,tin,uranium}_block.json` 分别读取 `c:ores/*`、`c:raw_materials/*`、`c:storage_blocks/raw_*`，条件为对应标签非空。填入项目材料后存在激活这些配方的预期，尚未做重载验证。不能说全部矿碎配方都缺，更不能再盲目加同输入配方。
3. **已有矿碎参数和副产与策划不完全同义。** 三矿矿石配方输出粉碎粗矿及概率经验颗粒，没有策划中部分行所写的副石料；现有数值保留在 J 原文，仅作依赖事实，不视为项目新配方批准值。是否直接接受已有结果或在批准后替换，需 PM 整理材料关系差异。
4. **三矿洗涤与直接熔炼不是无第三方的完整来源。** 已找到的 `splashing/.../crushed_raw_*.json` 与 `smelting` / `blasting` 条目都带 `neoforge:mod_loaded` 条件，输出第三方金属。铅涉及 immersiveengineering、oreganized、mekanism、thermal；锡涉及 mekanism、ic2、thermal；铀涉及 immersiveengineering、mekanism、ic2。无这些模组时不能靠这些配方得到本项目铅/锡粒或铀精矿。未来项目洗涤与这些条件配方在安装对应模组时可能竞争，特别是铀会分流至普通铀粒；本轮未联调。
5. **黑曜石粉可复用。** `data/create/recipe/crushing/obsidian.json`：黑曜石→`create:powdered_obsidian`，另有概率返还黑曜石。`sequenced_assembly/sturdy_sheet.json` 从 `c:dusts/obsidian` 开始，经熔岩灌注和压片得到坚固板。重型轴承因此依赖已有粉碎轮/注液器/压片机路线，而不依赖核机组。项目 `obsidian_dust` 只是规划项，未授权删除或改名。
6. **青金石设备分工有静态支持。** `milling/lapis_lazuli.json` 为青金石→蓝色染料；V `CrushingWheelControllerBlockEntity.findRecipe()`（959–979）先查 `CRUSHING`，找不到才查 `MILLING`。所以 D-02a 的粉碎专用制粉、磨石保留染料在类型上可表达，但新配方不存在、实际匹配及重载尚未验证。

### 6.2 按阻塞程度排列的问题

分类：**决策**＝玩法/材料关系尚有取舍；**实现**＝已确认关系缺实现；**常规补齐**＝原则已确认，可由 PM 在后续明确写集后安排；**技术验证**＝不能仅凭静态证据判通过。任何分类均不授权本执行者修改。

| 问题 | 证据、影响 | 候选处理与分类；本轮停止位置 |
|---|---|---|
| F01 煤/木炭磨石制粉与染料竞争 | R196；J `milling/coal.json`、`milling/charcoal.json` 已占同输入；粉碎轮还会回退磨石配方 | **决策+技术验证**：可考虑粉碎专用制粉并保留磨石、或经批准调整既有路线；不能把只针对青金石的 D-02a 自动扩大到煤/木炭，也不能靠遍历顺序选结果 |
| F02 黑曜石双产物身份、矿碎已有配方 | R198 和 C78 保留项目粉末；J 已有黑曜石及三矿条件配方；矿石副产与表格存在差别 | **决策**：复用现有 Create 输出并按标签消费，或批准明确替换/区分路线；不新增相同输入并赌优先级，不删除已登记身份 |
| F03 钢板压片多产物与多输入压片 | R216/218/262 同钢板可制密封环、网、包壳；R203 隔热板有两个输入。V `PressingRecipe.matches`、`getMaxInputCount()`（11–32）只读一个输入；`MechanicalPressBlockEntity.getRecipe()`（382–405）依序列状态或单输入查找 | **决策+技术验证**：可在文档允许的切石、序列工序或盆压缩之间明确分工；新增模具、半成品、额外原料会改变依赖，不能自批。无过滤/区分合同前不把三行直接生成 pressing JSON |
| F04 首次烧结热源未冻结 | R146/261/322 只规定专用密闭高温炉及制造用烈焰人燃烧室；准备计划明确烧结热源待定 | **决策+技术验证**：需要明确可在第一批燃料前取得的非核供热方式、实际读取接口和故障行为；现有 Create 热级仅作候选能力证据，不宣称专用炉已支持它 |
| F05 已冻结燃料柱缺制造来源 | P1Blocks42,58–59；C151；R第12节无对应产出行；S 无配方 | **决策+实现**：PM 补齐 `reactor_fuel_rod` 的材料与设备关系；不以 `fresh_fuel_rod`、组件或结构掉落替代初始来源 |
| F06 首发装配台与 P3 机械臂阶段不闭合 | C168 要求支持专用机械臂自动化，C174 把 `shielded_manipulator` 列P3；project.md135 允许屏蔽机械臂或密闭机器无人值守；R54 已允许手动 | **决策澄清+技术验证**：明确首发密闭台本身的自动化接口是否足够，或是否另有已批准搬运边界；不擅自提前P3机械臂。人工搬运不需重新批准，也不自动保证所有料浆容器已实现 |
| F07 重型轴承、传感器阶段标签交叉 | R228 商用轴承→R321 燃料制造离心机；R225 燃料制造工业传感器→R226 勘探辐射传感器→R323 首台装配台 | **文档顺序澄清/常规计划整理**：材料图要求提前提供这些零件，无证据表明要先建核堆。提供零件身份不等于提前实现辐射检测/工业仪表功能；若要求更改材料或提前后期系统则转用户决策 |
| F08 洗涤“+水”表达 | R182 把水写输入；V `SplashingRecipe` 为单物品输入，`ProcessingRecipe.getMaxFluidInputCount()` 为0；真实 splashing 类型检查世界流体环境 | **决策澄清+技术验证**：若水只是鼓风洗涤介质，原生表达成立；若要求逐批扣液，现有类型不能直接承担。不能自造液量或修改洗涤设备以掩盖差异 |
| F09 机械装配、切石与两级燃料装配未落类型 | R136,219–221,264,322–323；“切石机”“机械装配”并非均为唯一 Create 类型 | **技术方案+必要决策**：原版 stonecutting 可被动力锯接受，但 V `SawBlockEntity.getRecipes()`（1048–1127）受 `allowStonecuttingOnSaw` 控制并有输出过滤；CRecipes 默认开启（153–171 字节码段）。需写清默认/改配置、过滤选择、序列半成品和自动化入口；普通手工转运不代替加工 |
| F10 缺生产身份、矿物来源和配方 | B注册、S资源清单、P1DataContractTest125–149 | **实现**：不是回归缺陷，P1原边界本就不含生存生产。按批准批次补齐，不以PNG、创造栏或探针配方宣称可达 |
| F11 通用标签与父汇聚不完整 | T；本项目只有钢子标签；粉碎粗矿只有Create集合；黑曜石粉父汇聚缺 | **常规补齐+技术验证**：按第5节显式追加已有具体标签与适用父；不得吸纳核专用材料或错误形态；跨模组真实性仍未验证 |
| F12 部分命名/原料范围未确定 | 钢轴与steel_rod映射、铅屏蔽构件ID、陶瓷/核材料专用标签、玻璃/混凝土范围、料浆容器 | **缺项/必要决策**：只标出未确定项；本轮不创设ID、不把不明确的原料范围扩大成全生态兼容 |

### 6.3 非核起步能力与循环边界

锁定 JAR 提供水车配方（`crafting/kinetics/water_wheel.json`）、机械合成器（`crafting/kinetics/mechanical_crafter.json`）、粉碎轮（`mechanical_crafting/crushing_wheel.json`）、电子管、精密构件和坚固板路线。粉碎轮本身需要机械合成器；其黄铜/电子管路线属于 Create 前置，不把它误记为仅手搓磨石门槛。最低转速、负载和首套设备数量本轮未核算或运行验证。

V `HeatCondition.testBlazeBurner()` 区分 `HEATED` 和仅接受 `SEETHING` 的 `SUPERHEATED`；Create 已有烈焰蛋糕的压盆与熔岩灌注配方以及燃烧室燃料判断（J `compacting/blaze_cake.json`、`filling/blaze_cake.json`；V `BlazeBurnerBlockEntity`）。这证明 Create 普通/超级加热不在概念上强制依赖核热，**不证明尚未实现的烧结炉能接受这些热源**，也不批准任一新配方加热等级。

按 R321–323 展开的三台设备制造输入均没有本机产品；首次离心工艺水是输出，料浆先用外来水，不必等回用水。尾矿屏蔽在装配台之后，不应反向要求先屏蔽尾矿才能继续第一批洗矿；需保留全部输出和暂存能力。以上为定性依赖推导，尚未验证容量或吞吐。

## 7. 最小前置顺序与第一批实现候选

此表是依赖审计建议，不派发任务，不解除 P1 人工门或 D-03 参数门。D-01 的先材料设备、再运行、再封存；D-02/02a 青金石粉身份、标签及设备分工；D-03a 适中投入与允许人工搬运均沿用，不复议。

| 顺序 | 必须先具备的内容 | 本轮可确定 / 停止点 |
|---|---|---|
| 0 | 原版/Create 动力、加工设备和非核供热；粉碎轮及其机械合成前置 | 可复用身份/配方；真实能力、吞吐未验；不核算数量 |
| 1A | `lapis_dust` 注册资源，`c:dusts/lapis`及父；粉碎专用制粉 | 已确认常规补齐候选；制粉参数待D-03；不得改磨石染料 |
| 1B | 铅/锡/铀来源与标签，复用三种Create粉碎粗矿；洗涤补项目输出 | 实现缺口；矿碎输出关系差异/洗水含义先澄清；矿物生成实现需未来专项技能与任务 |
| 1C | 碳粉、石英粉、钢锭/板、锡条/焊料、耐火砖及零件 | 碳粉竞争、钢板设备分工先决；标签接入原则已确认 |
| 2 | 工业传感器→辐射传感器；Create坚固板/精密构件→重型轴承 | 材料先于三台机器，不提前辐射行为；“轴”身份缺口保留 |
| 3 | 首台离心机、烧结炉、屏蔽装配台 | 制造材料图可列，烧结热源/装配设备与自动化边界未决；不越门实现 |
| 4 | 精矿+水→料浆→低浓缩粉+贫化粉+工艺水→生芯块→烧结芯块→棒→组件；冷却剂可并行 | 保留副产物、手动与自动路径、两级装配；料浆容器/机器事务与数值待合同 |
| 5 | 反应堆组成方块制造来源与燃料/冷却剂就绪 | `reactor_fuel_rod`来源未明确，阻塞完整生存建堆；不修改已有燃料耐久/容量 |
| 6 | 运行热端闭环之后，玻璃固化基材→灌封→铅桶→贮存 | 首发必含基础封存，但不反向成为全部生产前段前置；高放再处理后置 |

**第一批较小候选范围：** 青金石粉身份/资源/标签、通用父标签接入、已有钢板标签汇聚、矿物/粗加工标签清单及 Create 复用策略确认。具体配方实现仍须 PM 在参数确认后给出写集；不因本表而运行数据生成或修改旧测试。煤粉/木炭粉、黑曜石第二身份、钢板分支、专用烧结和屏蔽装配保持阻塞，直到各自决策明确。

## 8. 未来验证矩阵（全部未运行）

| 验证对象 | 需要的证据 | 通过条件 |
|---|---|---|
| 注册与资源 | 静态/资源契约+加载 | 正式ID、模型、标签、配方类型及引用有效；无未注册对象；占位PNG不能代替身份 |
| 标签等价与错误形态 | 受控追加数据包+真实配方匹配 | 同标签等价粉/金属可替代；整青金石、蓝染料、其他粉末拒绝；普通粉标签不接受核专用粉；父标签真实可枚举；replace:false不覆盖外部成员 |
| 无第三方可达 | 仅锁定必要依赖的专用测试环境+生存流程 | 原版/Create→项目矿物/材料→首台三机→首批燃料和冷却剂均有来源；不依赖条件关闭的第三方洗涤/熔炼 |
| 青金石与其他竞争 | 真实磨石/粉碎轮、钢板目标设备；前后数据包重载 | 青金石粉碎专用优先且磨石仍染料；煤/木炭/黑曜石按获批方案稳定；不依赖配方遍历顺序；三矿标签激活后无新同输入歧义 |
| 切石/动力锯、机械装配 | 实际设备和过滤配置 | 目标产品可选择；allowStonecuttingOnSaw开/关边界可解释；序列半成品有身份且可恢复；两级燃料装配不跳过 |
| 非核首次启动 | 空白进度下搭建、实测热源与动力 | 无核机组也能制出第一批燃料及冷却剂；专用烧结读取正确热源；断热/断动力状态符合后续合同 |
| 人工转运与自动化 | 玩家存取、料浆容器、传送带/机械手/管网及批准的装配台接口 | 人工不绕过工序；容器返还/余液守恒；自动输入输出真实运行；不误把既有反应堆动力机械臂端点等同于生产设备接口 |
| 副产物满/堵塞 | JUnit事务模型+真实设备GameTest | 精矿与尾矿、两类铀粉与工艺水全部保留；任一输出满时按合同停机/拒绝，不吞输入、不复制输出 |
| 模拟/执行、断动力和卸载恢复 | capability模拟/执行及NBT往返、真实区块卸载 | 模拟无副作用；进度、库存、余量只持久化一次；执行前复核空间；恢复不重复结算 |
| 现有P1边界回归 | 批准生产实现后定向及既有回归 | 组件耐久/唯一所有权不变；冷热不新增普通互转；错误流体拒绝；不能用生产补齐名义放宽安全合同 |
| 封存前段交接 | 未来运行与封存任务 | 枯竭组件可追踪灌封/装桶/贮存；基材来源可达；未实施P3辐射/再处理不得宣称完成 |

隔离数据包追加成员只证明标签接口，不能称真实第三方模组联调。副产物概率和负载参数未冻结前，本轮不设通过数值或成本总数。

## 9. 未验证事项、写集与交接

未验证：运行时注册/标签最终集合、数据包条件与重载行为、真实设备选方、矿物世界生成和生存获取、首次烧结热源、全部物品/流体自动化、真实第三方模组、配方平衡、客户端体验。锁定字节码/JSON仅支持本报告明确列出的静态事实。未穷尽后期设备，不细化事故、Ponder、高放再处理或热端探针；未把未知项填为通过。

本执行者实际写入：

- `build/reports/extension/EXT-A-DEPS-01.md`。
- `build/reports/extension/EXT-A-DEPS-01/` 中证据清单、JSON、反汇编、基线快照、标签矩阵、Git状态与交付清单。已有证据全部保留。

未修改代码、测试、资源、构建脚本、核心文档、配置或Git历史。报告目录被 `.gitignore:2:build/` 忽略，因此 Git 工作区干净不表示报告没有写入；以证据清单和文件为准。无运行行为、存档、NBT、注册或网络兼容变化；中文代码注释检查不适用，因为没有改代码。

本次完成的是有证据的最小依赖审计与阶段报告；已向项目经理交付决策门，由PM核验后向用户提出。未决实现保持阻塞，后续由 PM 抽查证据、整理用户决策及记录验收。执行者在此交付后停止，等待验收。
