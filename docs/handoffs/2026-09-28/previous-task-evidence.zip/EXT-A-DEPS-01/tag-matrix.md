# 锁定依赖与本仓库物品标签逐项证据

仅静态解析，不代表运行时标签或第三方验证。父标签列只列直接引用，斜杠不产生继承。铀金属暂缓，未使用形态不建议新增。

| 标签 | NeoForge 条目值 | Create 条目值 | 项目条目值 | 三来源直接父标签 |
|---|---|---|---|---|
| `c:dusts/lapis` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/redstone` | ["minecraft:redstone", {"id": "#forge:dusts/redstone", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/dusts.json |
| `c:dusts/glowstone` | ["minecraft:glowstone_dust", {"id": "#forge:dusts/glowstone", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/dusts.json |
| `c:dusts/quartz` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/coal` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/charcoal` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/glass` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/obsidian` | 无条目 | ["create:powdered_obsidian"] | 无条目 | 无直接父引用 |
| `c:gems/lapis` | ["minecraft:lapis_lazuli", {"id": "#forge:gems/lapis", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/gems.json; NF:data/neoforge/tags/item/enchanting_fuels.json |
| `c:gems/quartz` | ["minecraft:quartz", {"id": "#forge:gems/quartz", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/gems.json |
| `c:ingots/iron` | ["minecraft:iron_ingot", {"id": "#forge:ingots/iron", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/ingots.json |
| `c:ingots/copper` | ["minecraft:copper_ingot", {"id": "#forge:ingots/copper", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/ingots.json |
| `c:glass_blocks` | ["#c:glass_blocks/colorless", "#c:glass_blocks/cheap", "#c:glass_blocks/tinted", {"id": "#forge:glass", "required": false}] | 无条目 | 无条目 | 无直接父引用 |
| `c:glass_blocks/colorless` | ["minecraft:glass", {"id": "#forge:glass_colorless", "required": false}] | ["create:tiled_glass", "create:framed_glass", "create:horizontal_framed_glass", "create:vertical_framed_glass"] | 无条目 | NF:data/c/tags/item/glass_blocks.json |
| `c:obsidians` | ["#c:obsidians/normal", "#c:obsidians/crying", {"id": "#forge:obsidian", "required": false}] | 无条目 | 无条目 | 无直接父引用 |
| `c:obsidians/normal` | ["minecraft:obsidian"] | 无条目 | 无条目 | NF:data/c/tags/item/obsidians.json |
| `c:bricks/normal` | ["minecraft:brick", {"id": "#forge:ingots/brick", "required": false}] | 无条目 | 无条目 | NF:data/c/tags/item/bricks.json |
| `c:ores/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:raw_materials/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ingots/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:nuggets/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:plates/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:wires/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:rods/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:crushed_raw_materials/lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/raw_lead` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ores/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:raw_materials/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ingots/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:nuggets/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:plates/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:wires/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:rods/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:crushed_raw_materials/tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/raw_tin` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ores/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:raw_materials/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ingots/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:nuggets/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:dusts/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:plates/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:wires/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:rods/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:crushed_raw_materials/uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/raw_uranium` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ingots/steel` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:plates/steel` | 无条目 | 无条目 | ["create_nuclear_industry:steel_plate"] | 无直接父引用 |
| `c:rods/steel` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:storage_blocks/steel` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:plates/reinforced_steel` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `c:ingots/solder` | 无条目 | 无条目 | 无条目 | 无直接父引用 |
| `create:crushed_raw_materials` | 无条目 | ["create:crushed_raw_iron", "create:crushed_raw_gold", "create:crushed_raw_copper", "create:crushed_raw_zinc", "create:crushed_raw_osmium", "create:crushed_raw_platinum", "create:crushed_raw_silver", "create:crushed_raw_tin", "create:crushed_raw_lead", "create:crushed_raw_quicksilver", "create:crushed_raw_aluminum", "create:crushed_raw_uranium", "create:crushed_raw_nickel"] | 无条目 | 无直接父引用 |