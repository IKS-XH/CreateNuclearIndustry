"""原创像素设计记录：用离散色块构造新 SVG；正式导出不依赖此文件。

已批准四张 SVG 不重写。其余形体使用人工选择的轮廓、矿簇和机械结构，
不读取旧游戏 PNG 像素；基线清单仅用于确定既有路径、尺寸和用途。
"""
from pathlib import Path
import json
import xml.etree.ElementTree as ET

REPO = Path(__file__).resolve().parents[4]
ROOT = REPO/'tools/art-assets'
palette = json.loads((ROOT/'palette.json').read_text(encoding='utf-8'))
baseline = json.loads((ROOT/'baseline.json').read_text(encoding='utf-8'))
METAL = ['#28353A','#3E5058','#5B7078','#788E94','#A3B7B8','#D1DFDA']
BRASS = ['#715035','#AD7A42','#D2A359','#F0CF87']
TIN = ['#354249','#556875','#8AA4B1','#B9CED5','#E2E9DE']
LEAD = ['#303441','#464C5D','#60687A','#7E8798','#A6AFBF','#CDD3DE']
URANIUM = ['#343C32','#536347','#7D8954','#A9B56B','#D1D794']
COLD = ['#163E52','#235C71','#367E92','#52A2AD','#83C4C8']
HOT = ['#59392E','#925039','#BC714A','#E39C60','#F4C985']
STONE = ['#646460','#767671','#878780','#96958D']
DEEP = ['#343A41','#454C54','#59616A','#707881']

class Pixels:
    """整数像素画布，所有颜色为实色；空像素只用于物品边缘和窗口。"""
    def __init__(self, h=16, fill=None):
        self.h=h; self.rows=[[fill]*16 for _ in range(h)]
    def rect(self,x,y,w,h,c):
        assert 0<=x<x+w<=16 and 0<=y<y+h<=self.h
        for yy in range(y,y+h):
            for xx in range(x,x+w): self.rows[yy][xx]=c
        return self
    def dots(self,points,c):
        for x,y in points: self.rect(x,y,1,1,c)
        return self
    def stamp(self,x,y,rows,colors):
        for dy,row in enumerate(rows):
            for dx,key in enumerate(row):
                if key!='.': self.rect(x+dx,y+dy,1,1,colors[key])
        return self

def svg(name,p,description):
    """按行合并同色矩形，SVG 保留为真正可逐块编辑的源稿。"""
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="16" height="{p.h}" viewBox="0 0 16 {p.h}" shape-rendering="crispEdges">',f'  <!-- {description} -->']
    colors=[]
    for y,row in enumerate(p.rows):
        x=0
        while x<16:
            end=x+1
            while end<16 and row[end]==row[x]: end+=1
            color=row[x]
            if color:
                if color not in colors: colors.append(color)
                parts.append(f'  <rect x="{x}" y="{y}" width="{end-x}" height="1" fill="{color}"/>')
            x=end
    assert len(colors)<=16,(name,len(colors))
    parts.append('</svg>')
    path=ROOT/'sources'/f'{name}.svg'; path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text('\n'.join(parts)+'\n',encoding='utf-8')
    palette[name.split('/')[-1]]={f'color_{i:02}':c for i,c in enumerate(colors)}

def approved_ore():
    p=Pixels()
    for node in ET.parse(ROOT/'sources/block/lead_ore.svg').getroot():
        p.rect(*[int(node.get(k)) for k in ('x','y','width','height')],node.get('fill'))
    return p

# 岩底与首稿一致，矿簇轮廓按矿物调整；深层岩只更换母岩，不更换矿物身份色。
rock=approved_ore()
for material,colors in [('lead',LEAD),('tin',TIN),('uranium',URANIUM)]:
    for deep in (False,True):
        name=f'block/{"deepslate_" if deep else ""}{material}_ore'
        if name=='block/lead_ore': continue
        p=Pixels()
        for y in range(16):
            for x in range(16):
                old=rock.rows[y][x]
                if old in STONE: index=STONE.index(old)
                else: index=1
                p.rect(x,y,1,1,(DEEP if deep else STONE)[index])
        orecolors=dict(zip('osblg',[colors[0],colors[1],colors[2],colors[-2],colors[-1]]))
        if material=='lead':
            leadmap={'#404550':LEAD[0],'#5B6475':LEAD[2],'#818B9F':LEAD[3],'#B3BECE':LEAD[4]}
            for y in range(16):
                for x in range(16):
                    if rock.rows[y][x] in leadmap:p.rect(x,y,1,1,leadmap[rock.rows[y][x]])
        elif material=='tin':
            p.stamp(1,2,['.g...','llso.','.bbls','..so.'],orecolors)
            p.stamp(10,1,['.gl..','lbs..','.bo..'],orecolors)
            p.stamp(6,9,['..g.','.lbs','glbs','.so.','b...'],orecolors)
            p.stamp(13,12,['l.','bs','.o'],orecolors)
        else:
            p.stamp(3,1,['.l..','gls.','.bso','..b.'],orecolors)
            p.stamp(10,6,['..l.','.gbs','lbso','.so.'],orecolors)
            p.stamp(1,11,['l...','lbs.','.lb.','..s.'],orecolors)
            p.stamp(8,13,['.lb','lbs','.s.'],orecolors)
        svg(name,p,'原创碎岩底与不规则矿簇；左上矿面受光，深层与普通矿仅母岩不同。')

for material,colors in [('lead',LEAD),('tin',TIN),('uranium',URANIUM)]:
    mapping=dict(zip('osblg',[colors[0],colors[1],colors[2],colors[-2],colors[-1]]))
    p=Pixels().stamp(2,3,[
        '....oo......','..oollso....','.ogllbblso..','olglbbblbso.',
        'olbbbblbbsso','.obblgbbso..','..osbbbsbso.','...oossooo..'],mapping)
    if material=='uranium': p.dots([(4,7),(9,5),(8,10)],colors[-2])
    svg(f'item/raw_{material}',p,'粗矿物品：不规则多面矿块，透明外圈；矿物色和石质暗面区分。')
    p=Pixels(fill=colors[0])
    # 大小和朝向略异的矿块交错堆积，边缘取模保持平铺延续，暗缝不连成整齐格线。
    shapes=[['.llllss.','lggllbbs','lglbbbbs','llbbbbso','sbbbbsso','.ssbsso.','..ooo...'],
            ['.llls...','lglbbso.','llbbbbso','sbbblbso','ssbbbso.','.ssssso.','..ooo...']]
    for x,y,index in [(0,0,0),(8,0,1),(4,5,1),(-3,6,0),(11,6,0),(1,12,1),(8,12,0)]:
        for dy,row in enumerate(shapes[index]):
            for dx,key in enumerate(row):
                if key!='.':p.rect((x+dx)%16,(y+dy)%16,1,1,mapping[key])
    svg(f'block/raw_{material}_block',p,'粗矿堆积块：不同大小的矿块交错咬合，边界循环延续，不画外框。')

for material,colors in [('lead',LEAD),('tin',TIN)]:
    p=Pixels(fill=colors[2]);p.rect(1,1,14,14,colors[3]).rect(2,2,12,1,colors[-1])
    p.rect(2,3,1,10,colors[-2]).rect(3,13,11,1,colors[1]).rect(13,3,1,10,colors[2])
    p.rect(4,5,5,1,colors[-2]).rect(7,9,4,1,colors[2])
    p.dots([(1,1),(14,1),(1,14),(14,14)],colors[-2])
    svg(f'block/{material}_block',p,'压铸金属储存块：左上倒角亮边、右下暗边，有限色块体现金属平面。')

p=Pixels().stamp(1,3,['.....ooooo....','...oogggglo...','..oglmmmmbso..','.olmmmmmbbsso.',
    'ollllllbbssso.','osbbbbbsssso..','.osssssssoo...','..ooooooo.....'],dict(zip('osbmlg',[TIN[0],TIN[1],TIN[2],TIN[3],TIN[4],'#F2F1E6'])))
svg('item/tin_ingot',p,'锡锭：偏亮银灰平顶锭，左上高光，保持透明外圈。')
p=Pixels().stamp(1,3,['......os......','.....olbo.....','...oolgbso....','..olglbblso...','.olblglbbsso..','olglbblglbbso.','.osblblbbssso.','..obsbssbso...','.bo.osso..so..'],dict(zip('osblg',URANIUM)))
svg('item/uranium_concentrate',p,'铀精矿：低饱和黄绿颗粒团，区别于粗矿的不规则大块。')

def panel(kind='side'):
    """共用结构件钢制包边；顶、底和侧面的构图各自独立。"""
    p=Pixels(fill=METAL[0]);p.rect(1,1,14,14,METAL[2]).rect(2,2,12,12,METAL[1])
    p.rect(1,1,14,1,METAL[4]).rect(1,2,1,12,METAL[3]).rect(2,14,13,1,METAL[0])
    p.dots([(2,2),(13,2),(2,13),(13,13)],BRASS[2])
    p.dots([(3,2),(14,2),(3,13),(14,13)],BRASS[0])
    return p

def ring(p,colors,inner=METAL[0]):
    """无朝向箭头的对称法兰，保持现有 cube_bottom_top 的各侧等价。"""
    p.stamp(4,4,['..llll..','.lbbsso.','lbo..sso','lb....so','lb....so','os....so','.osssso.','..oooo..'],{'l':colors[-1],'b':colors[2],'s':colors[1],'o':colors[0]})
    p.rect(6,6,4,4,inner)
    return p

p=panel();p.rect(3,3,10,4,METAL[2]).rect(3,8,10,5,METAL[2]).rect(4,3,8,1,METAL[3]).rect(4,9,1,3,METAL[3])
svg('block/reactor_casing_side',p,'外壳侧面：上下两片钢板与水平接缝，左上受光。')
p=ring(panel(),METAL);p.rect(6,6,4,4,METAL[2]).rect(6,6,3,1,METAL[4]).rect(7,7,2,2,METAL[1])
svg('block/reactor_casing_top',p,'外壳顶面：钢制圆角检修盖，不绘制端口颜色。')
p=panel();p.rect(3,7,10,2,METAL[2]).rect(7,3,2,10,METAL[2])
for x,y in [(4,4),(10,4),(4,10),(10,10)]:p.rect(x,y,2,2,METAL[0])
svg('block/reactor_casing_bottom',p,'外壳底面：十字加劲筋与四角内凹区，区别于顶盖。')

for state,colors in [('cold',COLD),('hot',HOT)]:
    for face in ('side','top'):
        p=ring(panel(),colors)
        if face=='side':
            p.rect(0,7,3,2,colors[2]).rect(12,7,4,2,colors[1])
        else:
            p.rect(6,3,4,1,colors[-1]).rect(6,11,4,1,METAL[0])
        svg(f'block/reactor_{state}_port_{face}',p,'冷蓝或热暖法兰端口；侧面有管接线，顶面为独立开口，无方向箭头。')

for face in ('side','top'):
    p=panel()
    if face=='top':
        p.rect(3,3,10,10,BRASS[0]).rect(4,3,8,1,BRASS[-1]).rect(3,4,1,8,BRASS[2]).rect(5,5,6,6,METAL[0])
        p.rect(6,6,4,4,METAL[1]).rect(7,6,1,4,METAL[3])
    else:
        p.rect(4,3,8,10,METAL[0]).rect(4,3,8,1,BRASS[2]).rect(4,12,8,1,BRASS[0])
        p.rect(4,5,2,5,BRASS[1]).rect(10,5,2,5,BRASS[1]).rect(6,6,4,3,METAL[1])
    svg(f'block/reactor_refueling_port_{face}',p,'换料口：黄铜方形装料口与双侧把手，顶侧形态分别保留。')
    p=panel()
    if face=='side':
        p.rect(3,3,10,7,BRASS[0]).rect(4,4,8,5,METAL[0]).rect(5,5,6,3,METAL[4])
        p.dots([(5,7),(10,7)],METAL[2]).rect(8,5,1,3,HOT[2])
        p.rect(4,11,3,1,COLD[3]).rect(9,11,3,1,BRASS[2])
    else:
        p.rect(4,3,8,10,METAL[0]).rect(5,4,6,8,METAL[2]).rect(6,5,4,4,METAL[1])
        p.rect(7,6,2,2,BRASS[2]).rect(6,10,4,1,METAL[4])
    svg(f'block/reactor_instrument_port_{face}',p,'仪表端口：侧面为无文字的表针和状态灯，顶面为接线检修盖。')
    p=panel()
    if face=='top':
        p.rect(4,3,8,10,BRASS[0]).rect(4,3,8,1,BRASS[2]).rect(6,4,4,8,METAL[0]).rect(7,5,2,6,METAL[3])
    else:
        p.rect(4,3,8,4,METAL[0]).rect(5,4,5,2,METAL[3]).rect(10,4,1,2,BRASS[2])
        p.rect(5,9,6,4,METAL[0]).rect(6,10,4,2,METAL[2]).rect(7,10,1,2,METAL[4])
        p.rect(2,7,3,1,BRASS[2]).rect(11,7,3,1,BRASS[1])
    svg(f'block/control_rod_drive_{face}',p,'控制棒驱动器：顶面导轨槽与侧面执行机构，黄铜连接件不表达新动画。')
    p=panel()
    if face=='top':
        for x in (4,7,10):
            for y in (4,7,10):p.rect(x,y,2,2,BRASS[0]).rect(x,y,1,1,BRASS[-1])
    else:
        for x in (4,7,10):p.rect(x,3,2,10,BRASS[0]).rect(x,3,1,10,BRASS[2])
        p.rect(3,5,10,1,METAL[3]).rect(3,10,10,1,METAL[2])
    svg(f'block/reactor_fuel_rod_{face}',p,'燃料列：顶面九孔棒束，侧面三列金属棒与两道固定架。')

p=panel();p.rect(3,3,10,10,None).rect(3,3,10,1,METAL[4]).rect(3,4,1,9,METAL[3])
p.rect(4,12,9,1,METAL[1]).rect(12,4,1,8,METAL[1])
svg('block/reactor_window',p,'观察窗：中间八乘八像素完全透明，仅金属框受光，保留内部观察。')

for face in ('side','top'):
    p=ring(panel(),COLD,inner=METAL[1])
    if face=='top':
        p.rect(7,4,2,4,METAL[4]).rect(8,7,4,2,METAL[3]).rect(7,8,2,4,METAL[2]).rect(4,7,4,2,METAL[3])
        p.rect(7,7,2,2,BRASS[2])
    else:
        p.rect(5,6,6,4,METAL[2]).rect(6,6,4,1,METAL[4]).rect(6,9,4,1,METAL[0])
    svg(f'block/main_coolant_pump_{face}',p,'冷却剂泵：顶面叶轮与侧面泵壳，沿用现有静态纹理用途。')
p=panel();p.rect(5,0,6,16,METAL[0]).rect(6,0,4,16,METAL[2]).rect(6,0,1,16,METAL[4])
for y in (3,11):p.rect(3,y,10,2,BRASS[0]).rect(3,y,10,1,BRASS[2])
svg('block/pressure_pipe_tier_1',p,'一级压力管：纵向管身与两道黄铜箍，仅重绘既有素材。')
p=ring(panel(),BRASS);p.rect(7,4,2,8,BRASS[2]).rect(4,7,8,2,BRASS[1]).rect(7,7,2,2,METAL[4])
svg('block/pressure_valve_tier_1',p,'一级压力阀：黄铜手轮和中央轴，仅重绘既有素材。')

for spent in (False,True):
    p=Pixels();c=METAL if spent else BRASS+[BRASS[-1]]
    for x in (5,7,9):p.rect(x,3,2,10,METAL[0]).rect(x,3,1,10,c[2])
    p.rect(4,2,8,2,METAL[1]).rect(4,2,8,1,METAL[4]).rect(4,12,8,2,METAL[1])
    p.rect(5,12,6,1,METAL[3]).rect(4,6,8,1,METAL[2]).rect(4,10,8,1,METAL[2])
    p.rect(6,4,1,2,COLD[2] if spent else BRASS[-1])
    svg('item/'+('cooled_spent_fuel_assembly' if spent else 'fresh_fuel_assembly'),p,'燃料组件：竖直棒束和横向固定架；新燃料暖金属，冷却乏燃料暗灰蓝，不发光。')
p=Pixels();p.rect(7,2,2,12,METAL[0]).rect(7,3,1,10,METAL[3]).rect(5,2,6,2,BRASS[0]).rect(5,2,6,1,BRASS[2]).rect(6,12,4,2,BRASS[0]).rect(6,12,4,1,BRASS[1])
svg('item/control_rod',p,'控制棒物品：细长吸收棒与上下连接头，和燃料棒束轮廓不同。')
p=Pixels();p.rect(5,2,6,12,METAL[0]).rect(6,3,4,10,BRASS[1]).rect(6,3,4,1,BRASS[-1]).rect(6,5,4,4,METAL[1]).rect(7,6,2,2,COLD[3]).rect(7,10,2,1,METAL[0])
svg('item/dosimeter',p,'剂量计开发素材：手持黄铜仪表和蓝灰屏幕，不新增游戏功能。')
p=Pixels();p.rect(4,3,8,10,LEAD[0]).rect(5,2,6,1,LEAD[2]).rect(5,3,6,10,LEAD[3]).rect(5,3,1,10,LEAD[-2]).rect(6,3,5,1,LEAD[-1]).rect(4,5,8,1,LEAD[1]).rect(4,11,8,2,LEAD[1]).rect(6,7,4,2,BRASS[2]).rect(7,7,2,2,LEAD[0])
svg('item/lead_shielding_cask',p,'铅屏蔽桶开发素材：厚壁铅灰圆桶与黄铜识别箍，不注册新容器。')

for hot,colors in [(False,COLD),(True,HOT)]:
    for flow in (False,True):
        p=Pixels(64 if flow else 16,colors[1])
        # 人工设定的波纹片段在周期边界延续；flow 是完整静态长画布，不声明动画帧。
        for base in range(0,p.h,16):
            if flow:
                shapes=[(2,0,1,6,2),(3,4,1,5,3),(9,2,1,7,2),(10,7,1,6,3),(14,11,1,5,2),(5,12,1,4,0),(0,7,1,6,0)]
            else:
                shapes=[(1,2,4,1,3),(0,3,2,1,2),(5,3,2,1,2),(10,0,4,1,2),(9,1,2,1,3),(9,8,5,1,3),(8,9,2,1,2),(13,9,2,1,2),(2,12,5,1,2),(1,13,2,1,3),(6,13,2,1,0)]
            for x,y,w,h,c in shapes:p.rect(x,base+y,w,h,colors[c])
            p.dots([(2,base+1),(10,base+7)],colors[4])
        svg('fluid/'+('hot_' if hot else '')+'compound_coolant_'+('flow' if flow else 'still'),p,'冷蓝/热暖复合冷却剂；实色波纹，flow 保持完整16×64静态布局，不新增动画元数据。')

entries=[]
for old in baseline['records']:
    path=old['game']; stem=path[:-4]
    source='fluid/'+path.split('/')[-1][:-4] if 'compound_coolant' in path else stem
    group='coolant' if 'coolant_' in path and 'pump' not in path else ('items' if path.startswith('item/') else ('minerals' if any(k in path for k in ('ore','raw_','lead_block','tin_block')) else 'reactor'))
    kind='item' if path.startswith('item/') else ('window' if 'reactor_window' in path else 'opaque')
    entries.append({'game':path,'source':source+'.svg','palette':source.split('/')[-1],'size':old['size'],'kind':kind,'group':group,'use':old['use']})
entries.append({'game':None,'source':'item/lapis_dust.svg','palette':'lapis_dust','size':[16,16],'kind':'item','group':'items','use':'已批准候选，本批不新增注册和游戏PNG'})
(ROOT/'manifest.json').write_text(json.dumps({'schema':1,'entries':entries},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'palette.json').write_text(json.dumps(palette,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('原创源稿与清单就绪：',len(entries),'项；游戏路径51项，四组兼容流体共用源稿')
