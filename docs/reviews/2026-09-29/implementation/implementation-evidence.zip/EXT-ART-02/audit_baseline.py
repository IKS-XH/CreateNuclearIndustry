"""开工只读盘点游戏资源，保存路径、尺寸、哈希、引用及旧图对照，不修改游戏。"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
from PIL import Image, ImageDraw, ImageFont

REPO = Path(__file__).resolve().parents[4]
ROOT = REPO / 'src/main/resources/assets/create_nuclear_industry/textures'
ART = REPO / 'tools/art-assets'
EVIDENCE = Path(__file__).resolve().parent
files = sorted(ROOT.rglob('*.png'))
assert len(files) == 51
models = sorted((REPO / 'src/main/resources/assets/create_nuclear_industry/models').rglob('*.json'))
records = []
for path in files:
    name = path.relative_to(ROOT).as_posix()
    image = Image.open(path)
    ref = 'create_nuclear_industry:' + name[:-4]
    references = [str(p.relative_to(REPO)).replace('\\','/') for p in models if ref in p.read_text(encoding='utf-8')]
    if 'coolant' in name and name.startswith('block/'):
        references.append('src/main/java/com/iksxh/create_nuclear_industry/content/ModFluids.java:100-123 (动态 block/id_still 与 block/id_flow)')
    records.append({'game': name, 'size': list(image.size), 'mode': image.mode, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'references': references, 'use': '已引用纹理' if references else '本基线未引用素材；重绘不等于注册'})
    before = ART / 'baseline' / name
    before.parent.mkdir(parents=True, exist_ok=True)
    if before.exists():
        assert before.read_bytes() == path.read_bytes(), '已有基线不得覆盖'
    else:
        shutil.copyfile(path, before)
assert sum(r['size'] == [16,16] for r in records) == 47
assert sum(r['size'] == [16,64] for r in records) == 4
data = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(), 'count': len(records), 'records': records}
(EVIDENCE/'baseline.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ART/'baseline.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# 基线接触表只用于检查旧用途和整体布局，不作为新图的绘制输入。
sheet = Image.new('RGBA',(1100,1200),'#202730')
draw=ImageDraw.Draw(sheet)
font=ImageFont.load_default(size=11)
for index,record in enumerate(records):
    x=20+(index%7)*155; y=20+(index//7)*145
    old=Image.open(ROOT/record['game']).convert('RGBA')
    old=old.resize((64,64 if old.height==16 else 112),Image.Resampling.NEAREST)
    sheet.alpha_composite(old,(x,y))
    name=record['game'].split('/')[-1][:-4]
    draw.text((x,y+114),name[:23],font=font,fill='white')
    if len(name)>23: draw.text((x,y+126),name[23:],font=font,fill='white')
sheet.save(EVIDENCE/'baseline-contact.png')
print(json.dumps({'head':data['head'],'count':len(records),'unreferenced':[r['game'] for r in records if not r['references']]},ensure_ascii=False,indent=2))
