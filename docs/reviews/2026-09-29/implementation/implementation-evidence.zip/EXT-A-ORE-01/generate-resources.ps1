# 只生成EXT-A-ORE-01卡允许的JSON；PNG由独立美术任务维护。
$ErrorActionPreference='Stop'
$ns='create_nuclear_industry'
$res='src/main/resources'
function Write-Json($relative,$value) {
    $path=Join-Path $res $relative
    New-Item -ItemType Directory -Force (Split-Path $path) | Out-Null
    [IO.File]::WriteAllText((Join-Path (Get-Location) $path), ($value | ConvertTo-Json -Depth 40)+"`n")
}
function Add-Tag($relative,$values) {
    $path=Join-Path $res $relative
    $all=@()
    if(Test-Path $path){$all=@((Get-Content -Raw $path | ConvertFrom-Json).values)}
    Write-Json $relative ([ordered]@{replace=$false;values=@($all+$values | Select-Object -Unique)})
}
$specs=@(@{metal='lead';zh='铅';en='Lead';min=-48;max=32;count=6;size=7;air=0;tool='iron'},@{metal='tin';zh='锡';en='Tin';min=-16;max=112;count=12;size=8;air=0;tool='stone'},@{metal='uranium';zh='铀';en='Uranium';min=-64;max=-16;count=2;size=4;air=0.25;tool='iron'})
$zh=[ordered]@{}; $en=[ordered]@{}
foreach($s in $specs){
    $m=$s.metal
    $ids=@("${m}_ore","deepslate_${m}_ore","raw_${m}_block")
    foreach($id in $ids){
        Write-Json "assets/$ns/blockstates/$id.json" @{variants=@{''=@{model="${ns}:block/$id"}}}
        Write-Json "assets/$ns/models/block/$id.json" @{parent='minecraft:block/cube_all';textures=@{all="${ns}:block/$id"}}
        Write-Json "assets/$ns/models/item/$id.json" @{parent="${ns}:block/$id"}
        if($id -like 'raw_*'){
            $loot=@{type='minecraft:block';pools=@(@{rolls=1;entries=@(@{type='minecraft:item';name="${ns}:$id"});conditions=@(@{condition='minecraft:survives_explosion'})})}
        }else{
            $silk=@{type='minecraft:item';name="${ns}:$id";conditions=@(@{condition='minecraft:match_tool';predicate=@{predicates=@{'minecraft:enchantments'=@(@{enchantments='minecraft:silk_touch';levels=@{min=1}})}}})}
            $raw=@{type='minecraft:item';name="${ns}:raw_$m";functions=@(@{function='minecraft:apply_bonus';enchantment='minecraft:fortune';formula='minecraft:ore_drops'},@{function='minecraft:explosion_decay'})}
            $loot=@{type='minecraft:block';pools=@(@{rolls=1;entries=@(@{type='minecraft:alternatives';children=@($silk,$raw)})})}
        }
        Write-Json "data/$ns/loot_table/blocks/$id.json" $loot
    }
    Write-Json "assets/$ns/models/item/raw_$m.json" @{parent='minecraft:item/generated';textures=@{layer0="${ns}:item/raw_$m"}}
    $zh["block.$ns.${m}_ore"]=$s.zh+'矿石'; $en["block.$ns.${m}_ore"]=$s.en+' Ore'
    $zh["block.$ns.deepslate_${m}_ore"]='深层'+$s.zh+'矿石'; $en["block.$ns.deepslate_${m}_ore"]='Deepslate '+$s.en+' Ore'
    $zh["block.$ns.raw_${m}_block"]='粗'+$s.zh+'块'; $en["block.$ns.raw_${m}_block"]='Block of Raw '+$s.en
    $zh["item.$ns.raw_$m"]='粗'+$s.zh; $en["item.$ns.raw_$m"]='Raw '+$s.en
    $targets=@(@{target=@{predicate_type='minecraft:tag_match';tag='minecraft:stone_ore_replaceables'};state=@{Name="${ns}:${m}_ore"}},@{target=@{predicate_type='minecraft:tag_match';tag='minecraft:deepslate_ore_replaceables'};state=@{Name="${ns}:deepslate_${m}_ore"}})
    Write-Json "data/$ns/worldgen/configured_feature/ore_$m.json" @{type='minecraft:ore';config=@{targets=$targets;size=$s.size;discard_chance_on_air_exposure=$s.air}}
    Write-Json "data/$ns/worldgen/placed_feature/ore_$m.json" @{feature="${ns}:ore_$m";placement=@(@{type="${ns}:ore_generation";ore_tag="c:ores/$m";mode='auto'},@{type='minecraft:count';count=$s.count},@{type='minecraft:in_square'},@{type='minecraft:height_range';height=@{type='minecraft:trapezoid';min_inclusive=@{absolute=$s.min};max_inclusive=@{absolute=$s.max};plateau=0}},@{type='minecraft:biome'})}
    Write-Json "data/$ns/neoforge/biome_modifier/add_${m}_ore.json" @{type='neoforge:add_features';biomes='#minecraft:is_overworld';features="${ns}:ore_$m";step='underground_ores'}
    Write-Json "data/$ns/recipe/raw_${m}_block.json" @{type='minecraft:crafting_shaped';category='building';pattern=@('###','###','###');key=@{'#'=@{tag="c:raw_materials/$m"}};result=@{id="${ns}:raw_${m}_block";count=1}}
    Write-Json "data/$ns/recipe/raw_${m}_from_block.json" @{type='minecraft:crafting_shapeless';category='misc';ingredients=@(@{tag="c:storage_blocks/raw_$m"});result=@{id="${ns}:raw_$m";count=9}}
    foreach($kind in @('block','item')){
        Add-Tag "data/c/tags/$kind/ores/$m.json" @("${ns}:${m}_ore","${ns}:deepslate_${m}_ore")
        Add-Tag "data/c/tags/$kind/ores.json" @("#c:ores/$m")
        Add-Tag "data/c/tags/$kind/storage_blocks/raw_$m.json" @("${ns}:raw_${m}_block")
        Add-Tag "data/c/tags/$kind/storage_blocks.json" @("#c:storage_blocks/raw_$m")
    }
    Add-Tag "data/c/tags/item/raw_materials/$m.json" @("${ns}:raw_$m")
    Add-Tag 'data/c/tags/item/raw_materials.json' @("#c:raw_materials/$m")
    Add-Tag "data/c/tags/item/crushed_raw_materials/$m.json" @("create:crushed_raw_$m")
    Add-Tag 'data/c/tags/item/crushed_raw_materials.json' @("#c:crushed_raw_materials/$m")
    Add-Tag 'data/minecraft/tags/block/mineable/pickaxe.json' @($ids | ForEach-Object {"${ns}:$_"})
    Add-Tag "data/minecraft/tags/block/needs_$($s.tool)_tool.json" @($ids | ForEach-Object {"${ns}:$_"})
}
foreach($locale in @('zh_cn','en_us')){
    $path=Join-Path $res "assets/$ns/lang/$locale.json"
    $add=if($locale -eq 'zh_cn'){$zh}else{$en}
    $text=Get-Content -Raw $path
    $existing=$text | ConvertFrom-Json -AsHashtable
    $lines=@()
    foreach($key in $add.Keys){if(!$existing.ContainsKey($key)){$lines+=('  '+(ConvertTo-Json $key -Compress)+': '+(ConvertTo-Json $add[$key] -Compress))}}
    if($lines.Count){$text=$text.TrimEnd();$text=$text.Substring(0,$text.LastIndexOf('}')).TrimEnd()+",`n"+($lines -join ",`n")+"`n}`n";[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$text)}
}
