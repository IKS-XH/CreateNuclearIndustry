param([long]$Seed=20260929,[string]$RunName='seed-20260929',[string]$Pack='', [int]$Origin=120, [switch]$ExpectNone, [switch]$ReloadTags, [switch]$ReloadMode)
# 只在本卡证据目录创建隔离服务器，使用Gradle已生成的同版本启动参数；不触碰用户存档。
$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$evidence=Join-Path $root 'build/reports/extension/EXT-A-ORE-01'
$run=Join-Path $evidence "runs/$RunName"
New-Item -ItemType Directory -Force $run | Out-Null
[IO.File]::WriteAllText((Join-Path $run 'eula.txt'),"eula=true`n")
[IO.File]::WriteAllText((Join-Path $run 'server.properties'),"level-name=world`nlevel-seed=$Seed`nlevel-type=minecraft:normal`nserver-ip=127.0.0.1`nserver-port=0`nonline-mode=false`nspawn-protection=0`nview-distance=2`nsimulation-distance=2`nmax-tick-time=0`nsync-chunk-writes=false`n")
if($Pack){New-Item -ItemType Directory -Force (Join-Path $run 'world/datapacks') | Out-Null; Copy-Item -LiteralPath (Join-Path $evidence "packs/$Pack") -Destination (Join-Path $run 'world/datapacks') -Recurse}
$vm=(Get-Content (Join-Path $root 'build/moddev/gameTestServerRunVmArgs.txt') | Where-Object {$_ -ne '-Dneoforge.gameTestServer=true'}) -join "`n"
[IO.File]::WriteAllText((Join-Path $run 'vmargs.txt'),$vm+"`n-Xmx3G`n-Dcni.ore.sampleOrigin=$Origin`n-Dcni.ore.expectNone=$($ExpectNone.IsPresent.ToString().ToLower())`n")
$start=[Diagnostics.ProcessStartInfo]::new()
$start.FileName='C:/Program Files/Java/jdk-21/bin/java.exe'
$start.WorkingDirectory=$run
$start.UseShellExecute=$false
$start.CreateNoWindow=$true
$start.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
$start.RedirectStandardInput=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
$launch=Get-Content (Join-Path $evidence 'gametest-2-stopped-process.json') -Raw | ConvertFrom-Json
$classPath=[regex]::Match($launch.CommandLine,' -cp (.+?) net.neoforged.devlaunch.Main').Groups[1].Value
if(!$classPath){throw '未找到已验证启动类路径'}
$start.ArgumentList.Add('-Dfml.modFolders=create_nuclear_industry%%'+$root+'/build/classes/java/main;create_nuclear_industry%%'+$root+'/build/resources/main')
$start.ArgumentList.Add('@'+(Join-Path $run 'vmargs.txt'))
$start.ArgumentList.Add('-cp')
$start.ArgumentList.Add($classPath)
$start.ArgumentList.Add('@'+(Join-Path $root 'build/moddev/gameTestServerRunProgramArgs.txt'))
$start.ArgumentList.Add('--nogui')
$start.Environment['MOD_CLASSES']="create_nuclear_industry%%$root/build/classes/java/main;create_nuclear_industry%%$root/build/resources/main"
$process=[Diagnostics.Process]::new();$process.StartInfo=$start
$null=$process.Start()
$process.Id | Set-Content (Join-Path $run 'pid.txt')
$writer=[IO.StreamWriter]::new((Join-Path $run 'console.log'),$false,[Text.Encoding]::UTF8);$writer.AutoFlush=$true
$outRead=$process.StandardOutput.ReadLineAsync();$errRead=$process.StandardError.ReadLineAsync()
$timer=[Diagnostics.Stopwatch]::StartNew();$sent=$false;$stopped=$false;$sampleDone=$false;$reloadAt=-1;$reloaded=$false;$gateRuns=0
try{
 while(!$process.HasExited -or $outRead -or $errRead){
  foreach($stream in @('out','err')){
   $read=if($stream -eq 'out'){$outRead}else{$errRead}
   if($read -and $read.IsCompleted){
    $line=$read.GetAwaiter().GetResult()
    if($null -ne $line){
     $writer.WriteLine($line)
     if($line -match 'ORE_|failed|Exception|Done \('){Write-Output $line}
     if(!$sent -and $line -match 'Done \('){
      $process.StandardInput.WriteLine('execute positioned 0 120 0 run test run generationgateusesboundblocktagsandactualdimension')

      $process.StandardInput.Flush();$sent=$true
     }
     if($line -match 'ORE_GATE mineral=uranium'){
      $gateRuns++
      if($gateRuns -eq 1){$process.StandardInput.WriteLine('execute positioned 16 120 0 run test run naturalworldsample');$process.StandardInput.Flush()}
      elseif($ReloadTags -or $ReloadMode){$process.StandardInput.WriteLine('stop');$process.StandardInput.Flush();$stopped=$true}
     }
     if($line -match 'ORE_SAMPLE_DONE'){
      $sampleDone=$true
      if($ReloadMode){
       Get-ChildItem (Join-Path $run 'world/datapacks/disabled/data/create_nuclear_industry/worldgen/placed_feature') -Filter '*.json' | ForEach-Object {
        $data=Get-Content $_.FullName -Raw|ConvertFrom-Json;$data.placement[0].mode='enabled';$data|ConvertTo-Json -Depth 20|Set-Content $_.FullName
       }
       $process.StandardInput.WriteLine('reload');$process.StandardInput.Flush();$reloadAt=$timer.Elapsed.TotalSeconds
      }
      if($ReloadTags){$process.StandardInput.WriteLine('datapack disable "file/auto-external"');$process.StandardInput.Flush();$reloadAt=$timer.Elapsed.TotalSeconds}
     }
     if(!$stopped -and (($sampleDone -and !$ReloadTags -and !$ReloadMode) -or ($sent -and $line -match 'failed at'))){$process.StandardInput.WriteLine('stop');$process.StandardInput.Flush();$stopped=$true}
     if($stream -eq 'out'){$outRead=$process.StandardOutput.ReadLineAsync()}else{$errRead=$process.StandardError.ReadLineAsync()}
    }elseif($stream -eq 'out'){$outRead=$null}else{$errRead=$null}
   }
  }
  if($timer.Elapsed.TotalSeconds -gt 600){$writer.WriteLine('HARNESS_TIMEOUT_600S');$process.Kill($true);throw '隔离采样超过600秒'}
  if($reloadAt -ge 0 -and !$reloaded -and $timer.Elapsed.TotalSeconds -gt $reloadAt+5){
   $process.StandardInput.WriteLine('execute positioned 0 120 0 run test run generationgateusesboundblocktagsandactualdimension');$process.StandardInput.Flush();$reloaded=$true
  }
  Start-Sleep -Milliseconds 50
 }
 $process.WaitForExit()
 @("EXIT=$($process.ExitCode)","SAMPLE_DONE=$sampleDone","SEED=$Seed","PACK=$Pack") | Set-Content (Join-Path $run 'result.txt')
 Write-Output "RUN_RESULT $RunName exit=$($process.ExitCode) sample=$sampleDone"
}finally{$writer.Dispose();$process.Dispose()}
