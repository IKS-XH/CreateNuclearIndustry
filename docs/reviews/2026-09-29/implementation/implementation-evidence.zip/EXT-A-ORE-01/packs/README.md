# 三矿数据包测试包

这些包只用于隔离验收，不随模组发布。Minecraft 1.21.1 数据包格式48。将单个目录复制到测试世界的 `datapacks/`，应保留顶层 `pack.mcmeta`。勿将互相冲突的模式包同时启用。

- `auto-external`：向三个 `c:ores/<矿种>` **方块**标签追加 `minecraft:iron_ore`，模拟外部等价矿成员。默认auto将三矿全部关闭。这里只证明标签兼容机制，不是真实第三方矿模组联调。
- `enabled-external`：同样追加外部成员，并覆盖三条placed feature首项的mode为enabled，三矿仍生成。
- `disabled`：mode=disabled，停止三矿新生成。
- `item-only`：只向同名**物品**标签追加铁矿石物品；不触发方块矿物去重。

不装包即默认auto。所有模式始终限制实际minecraft:overworld。只影响之后生成的新区块；不会回填、删除、转换已有矿块。

标签属于运行时可重载数据：`/datapack disable "file/auto-external"` 会重载标签，auto在下一次放置读取当前成员。已实测三个矿的external=true/loadedAllows=false转为false/true。`/reload`不重建placed/configured feature动态注册表；修改mode/高度/次数/规模/暴露率后**保存退出并重启世界或服务器**。重启后去未生成区块验收，旧区块不作为切换失败的证据。

默认参数文件在 `src/main/resources/data/create_nuclear_industry/worldgen/`。覆盖某矿时保留完整configured/placed文件及namespace，只改批准的值；不要删除首个ore_generation过滤器，否则会移除维度和去重保护。

隔离复现（在功能工作树根执行，先完成Gradle编译与runGameTestServer参数生成）：

```powershell
./build/reports/extension/EXT-A-ORE-01/run-sample.ps1 -Seed 42 -RunName your-new-name
./build/reports/extension/EXT-A-ORE-01/run-sample.ps1 -Pack auto-external -RunName your-auto-test -ExpectNone -ReloadTags
./build/reports/extension/EXT-A-ORE-01/run-sample.ps1 -Pack enabled-external -RunName your-enabled-test
./build/reports/extension/EXT-A-ORE-01/run-sample.ps1 -Pack disabled -RunName your-disabled-test -ExpectNone
```

此证据脚本复用本机Gradle生成的启动classpath，需保留`gametest-2-stopped-process.json`；不是便携启动器。每次用新RunName避免读取旧区块。`runs/`全部为本卡生成的测试世界，未操作用户存档。客户端人工门请使用PM整合后的候选JAR。
