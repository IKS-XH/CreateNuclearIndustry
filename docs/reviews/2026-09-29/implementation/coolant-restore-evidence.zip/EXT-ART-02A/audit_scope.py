"""EXT-ART-02A 范围核对：比较开工快照和旧 Git 字节，不修改被测资源。"""
from pathlib import Path
import hashlib,json,subprocess
from PIL import Image
r=Path(__file__).resolve().parents[4]; a=r/'tools/art-assets'; out=Path(__file__).resolve().parent
before=json.loads((out/'before-files.json').read_text(encoding='utf-8'))
paths=list((r/'src').rglob('*'))+list((a/'sources').rglob('*'))+list((a/'baseline').rglob('*'))+list((a/'generated').rglob('*'))+[a/'baseline.json']
after={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
assert before.keys()==after.keys(),'文件集合发生变化'
retained={f'{folder}/{name}_{state}.png' for folder in ('block','fluid') for name in ('compound_coolant','hot_compound_coolant') for state in ('still','flow')}
game_prefix='src/main/resources/assets/create_nuclear_industry/textures/'
allowed={prefix+name for prefix in (game_prefix,'tools/art-assets/generated/') for name in retained}
changed={key for key in before if before[key]!=after[key]}
assert changed==allowed,sorted(changed^allowed)
original_records=json.loads((out/'coolant-before.json').read_text(encoding='utf-8'))
records=[]
for record in original_records:
    name=record['game']
    if name not in retained:continue
    original=subprocess.check_output(['git','show','eddd097^:'+game_prefix+name],cwd=r)
    assert original==(a/'baseline'/name).read_bytes()==(r/game_prefix/name).read_bytes()==(a/'generated'/name).read_bytes()
    record['after_sha256']=after[game_prefix+name]
    record['after_size']=list(Image.open(r/game_prefix/name).size)
    records.append(record)
unchanged_game=[key for key in before if key.startswith(game_prefix) and key.endswith('.png') and key not in allowed]
unchanged_generated=[key for key in before if key.startswith('tools/art-assets/generated/') and key not in allowed]
assert len(unchanged_game)==43
result={'result':'PASS','baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'changed_files':sorted(changed),'src_except_eight_coolant_unchanged':True,'baseline_and_sources_unchanged':True,'non_coolant_game_count':len(unchanged_game),'non_coolant_game_hashes':{key:after[key] for key in unchanged_game},'non_coolant_generated_count':len(unchanged_generated),'records':records}
(out/'scope-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'coolant-after.png').write_bytes((a/'previews/coolant-1.png').read_bytes())
print(json.dumps({key:value for key,value in result.items() if key not in ('records','non_coolant_game_hashes')},indent=2))
