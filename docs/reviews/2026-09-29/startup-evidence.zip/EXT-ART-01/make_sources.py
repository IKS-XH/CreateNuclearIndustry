"""首次原创草图的像素记录；只负责将手绘字符图转换成允许路径内的 SVG 源稿。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4] / "tools/art-assets"
PALETTE = json.loads((ROOT / "palette.json").read_text(encoding="utf-8"))
# 每行是人工指定的 16 个像素，横向同色像素合为可编辑矩形，不嵌入位图。
ART = {
    "item/lapis_dust": ("青金石粉：左上受光的松散粉堆，边缘碎粒和不规则色块保留粉末质感。", "osbflg", [
        "................", "................", "................", ".......os.......",
        "......olfso.....", "....osffbbso....", "...olgfblbbso...", "...offbblfbso...",
        "..oflbbfbbsbso..", ".osbffbbblbbso..", "..obbbflbbsbbso.", ".ofbblbbfbbssbo.",
        "..osbbbssbbsso..", ".bo.osssso..so..", "................", "................"
    ]),
    "item/lead_ingot": ("铅锭：低饱和冷灰厚锭，左上亮面与右下暗侧面明确分开。", "osbmlg", [
        "................", "................", "................", ".....ooooooo....",
        "....ogggllmso...", "...oglmmmmbsso..", "..oglmmmmmmbsso.", ".olmmmmmmmbbsso.",
        ".obllllllbbssso.", ".osbbbbbbbssso..", "..ossssssssso...", "...ooooooooo....",
        "................", "................", "................", "................"
    ]),
    "item/steel_plate": ("合金钢板：宽而薄的斜置钢板，左上倒角高光，右下仅一层厚边。", "osbmlg", [
        "................", "................", ".......oo.......", ".....oogloo.....",
        "...ooglmmmlso...", ".ooglmmmmmmmlso.", ".olmmmmmmmmmbso.", "..olmmmlmmmmbso.",
        "...olmmmmmmbso..", "....olmmmmbso...", ".....olmmbso....", "......olbso.....",
        ".......oso......", "........o.......", "................", "................"
    ]),
    "block/lead_ore": ("铅矿石：原创暖灰碎岩底纹，冷灰铅矿簇大小不一；边界不画外框以供平铺。", "dmlgsabc", [
        "mmllmmmdmmlmmmmd", "mlgglmmddlmmllmm", "mllldmcmmmlcgglm", "mmdmmcbaamllddmm",
        "lldmmbbscammdmmm", "glmmmsaabbsmmmll", "lmbdmmmsbammmlgl", "mmdllmmmdmmmlllm",
        "mmllglmmmmddmmbm", "ldmlcmdmmllmcbaa", "ldmcbadmlglmmbsm", "mmbbaasmlldmmsam",
        "mlcsbmsmmdmmmcsm", "lmmbabsmmmlldmml", "lmmsmsmmmlgglmml", "mmmdmmmmdmllmmmd"
    ])
}
for name, (description, symbols, rows) in ART.items():
    assert len(rows) == 16 and all(len(row) == 16 for row in rows), name
    colors = dict(zip(symbols, PALETTE[name.split("/")[1]].values(), strict=True))
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" shape-rendering="crispEdges">', f'  <!-- {description} -->']
    for y, row in enumerate(rows):
        x = 0
        while x < 16:
            end = x + 1
            while end < 16 and row[end] == row[x]:
                end += 1
            if row[x] != ".":
                parts.append(f'  <rect x="{x}" y="{y}" width="{end-x}" height="1" fill="{colors[row[x]]}"/>')
            x = end
    parts.append("</svg>")
    target = ROOT / "sources" / (name + ".svg")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(parts) + "\n", encoding="utf-8")
    print(target.relative_to(ROOT))
