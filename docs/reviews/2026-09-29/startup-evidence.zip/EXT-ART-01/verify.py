"""本卡的一次性证据检查：PNG 合同、独立像素对照、非法 SVG 拒绝和重复导出。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

from PIL import Image, ImageDraw

# 禁止导入工具时生成写集之外的 __pycache__。
sys.dont_write_bytecode = True
EVIDENCE = Path(__file__).resolve().parent
REPO = EVIDENCE.parents[3]
ROOT = REPO / "tools/art-assets"
spec = importlib.util.spec_from_file_location("art_export", ROOT / "export.py")
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)
palette = exporter.read_palette()
results = {"python": sys.executable, "textures": {}, "rejected": []}
for name, _, _ in exporter.ASSETS:
    source = ROOT / "sources" / (name + ".svg")
    path = ROOT / "generated" / (name + ".png")
    with Image.open(path) as output:
        assert output.format == "PNG" and output.size == (16, 16) and output.mode == "RGBA", name
        colors = {tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for v in palette[name.split("/")[1]].values()}
        pixels = list(output.get_flattened_data())
        assert {p[3] for p in pixels} <= {0, 255}, name
        assert {p[:3] for p in pixels if p[3]} <= colors, name
        assert all(p == (0, 0, 0, 0) for p in pixels if not p[3]), name
        exporter.validate_texture(name, output)
        # 使用 Pillow 矩形绘图 API 独立重建源稿，核对导出器手动像素覆盖的边界。
        reference = Image.new("RGBA", (16, 16))
        draw = ImageDraw.Draw(reference)
        for node in ET.fromstring(source.read_text(encoding="utf-8")):
            x, y, w, h = [int(node.get(k)) for k in ("x", "y", "width", "height")]
            draw.rectangle((x, y, x + w - 1, y + h - 1), fill=node.get("fill"))
        assert reference.tobytes() == output.tobytes(), name
        results["textures"][name] = {
            "mode": output.mode, "size": list(output.size),
            "opaque_colors": len({p[:3] for p in pixels if p[3]}),
            "alpha": sorted({p[3] for p in pixels}),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }

start = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" shape-rendering="crispEdges">'
rect = '<rect x="1" y="1" width="2" height="3" fill="#182746"/>'
valid = start + rect + '</svg>'
bad = {
    "path": valid.replace(rect, '<path d="M0 0L2 2"/>'),
    "image": valid.replace(rect, '<image href="data:image/png;base64,AAAA"/>'),
    "external_use": valid.replace(rect, '<use href="https://example.invalid/a.svg"/>'),
    "group": valid.replace(rect, '<g>' + rect + '</g>'),
    "gradient": valid.replace(rect, '<linearGradient id="g"/>'),
    "filter": valid.replace(rect, '<filter id="f"/>'),
    "root_style": valid.replace('width="16"', 'style="opacity:0.5" width="16"', 1),
    "transform": valid.replace('<rect ', '<rect transform="translate(1 1)" '),
    "opacity": valid.replace('<rect ', '<rect opacity="0.5" '),
    "stroke": valid.replace('<rect ', '<rect stroke="#182746" '),
    "rounded_rect": valid.replace('<rect ', '<rect rx="1" '),
    "fractional_x": valid.replace('x="1"', 'x="1.5"'),
    "negative_x": valid.replace('x="1"', 'x="-1"'),
    "zero_width": valid.replace('width="2"', 'width="0"'),
    "out_of_bounds": valid.replace('width="2"', 'width="16"'),
    "missing_attr": valid.replace(' height="3"', ''),
    "named_color": valid.replace('#182746', 'blue'),
    "off_palette": valid.replace('#182746', '#000000'),
    "alpha_hex": valid.replace('#182746', '#18274680'),
    "paint_url": valid.replace('#182746', 'url(#g)'),
    "wrong_namespace": valid.replace('http://www.w3.org/2000/svg', 'urn:other'),
    "wrong_viewbox": valid.replace('0 0 16 16', '0 0 32 32'),
    "text": valid.replace(rect, 'not a shape' + rect),
    "rect_child": valid.replace('/>', '><title>hidden</title></rect>'),
    "tail": valid.replace(rect, rect + 'text'),
    "doctype": '<!DOCTYPE svg>' + valid,
    "processing_instruction": valid.replace(rect, '<?hidden skip?>' + rect),
    "empty": start + '</svg>',
}
for name, text in bad.items():
    try:
        exporter.render_svg(text, {"#182746"})
    except (ValueError, ET.ParseError):
        results["rejected"].append(name)
    else:
        raise AssertionError(f"非法源稿被接受: {name}")

# 同色覆盖顺序和矩形右下边界的正向小例，避免只测试拒绝路径。
sample = exporter.render_svg(valid, {"#182746"})
assert sample.getpixel((1, 1)) == (24, 39, 70, 255)
assert sample.getpixel((2, 3)) == (24, 39, 70, 255)
assert sample.getpixel((3, 3)) == (0, 0, 0, 0)
overlap = valid.replace('</svg>', '<rect x="1" y="1" width="1" height="1" fill="#203D76"/></svg>')
assert exporter.render_svg(overlap, {"#182746", "#203D76"}).getpixel((1, 1)) == (32, 61, 118, 255)
outputs = [ROOT / "generated" / (name + '.png') for name, _, _ in exporter.ASSETS] + [ROOT / "preview.png", ROOT / "preview.html"]
def hashes():
    """记录全部六个派生输出，而不是仅记录四张游戏候选 PNG。"""
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}
before = hashes()
logs = []
for attempt in range(2):
    result = subprocess.run([sys.executable, str(ROOT / 'export.py')], cwd=REPO, text=True, encoding='utf-8', capture_output=True, check=True)
    logs.append(f"RUN {attempt + 1}: {sys.executable} tools/art-assets/export.py\n" + result.stdout + result.stderr)
    assert hashes() == before, '重复导出产生差异'
results['repeat_exports'] = 2
results['outputs_sha256'] = before
results['source_png_pixel_match'] = True
results['result'] = 'PASS'
(EVIDENCE / 'export-runs.txt').write_text('\n'.join(logs), encoding='utf-8')
(EVIDENCE / 'verification.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
