param([string]$ProjectRoot = (Resolve-Path '.').Path)

$ErrorActionPreference = 'Stop'
$extension = Join-Path $ProjectRoot 'build/reports/extension'
$report = Join-Path $extension 'EXT-A-MATERIAL-05'
$names = @(
    'EXT-A-MATERIAL-05.md',
    'EXT-A-MATERIAL-05/material-05.init.gradle',
    'EXT-A-MATERIAL-05/verify-artifact.ps1',
    'EXT-A-MATERIAL-05/verify-default-run.ps1',
    'EXT-A-MATERIAL-05/make-evidence.ps1',
    'EXT-A-MATERIAL-05/red-gametest.log',
    'EXT-A-MATERIAL-05/red-exit.txt',
    'EXT-A-MATERIAL-05/red-stop.txt',
    'EXT-A-MATERIAL-05/green-probe-1.log',
    'EXT-A-MATERIAL-05/green-probe-1-exit.txt',
    'EXT-A-MATERIAL-05/green-probe-1-stop.txt',
    'EXT-A-MATERIAL-05/green-probe-2.log',
    'EXT-A-MATERIAL-05/green-probe-2-exit.txt',
    'EXT-A-MATERIAL-05/green-probe-2-stop.txt',
    'EXT-A-MATERIAL-05/green-probe-3.log',
    'EXT-A-MATERIAL-05/green-probe-3-exit.txt',
    'EXT-A-MATERIAL-05/green-probe-3-stop.txt',
    'EXT-A-MATERIAL-05/compile-1.log',
    'EXT-A-MATERIAL-05/final-test-build.log',
    'EXT-A-MATERIAL-05/final-test-build-exit.txt',
    'EXT-A-MATERIAL-05/final-gametest.log',
    'EXT-A-MATERIAL-05/final-gametest-exit.txt',
    'EXT-A-MATERIAL-05/final-gametest-stop.txt',
    'EXT-A-MATERIAL-05/junit-summary.txt',
    'EXT-A-MATERIAL-05/fix1-build.log',
    'EXT-A-MATERIAL-05/fix1-build-exit.txt',
    'EXT-A-MATERIAL-05/fix1-gametest.log',
    'EXT-A-MATERIAL-05/fix1-gametest-exit.txt',
    'EXT-A-MATERIAL-05/fix1-gametest-stop.txt',
    'EXT-A-MATERIAL-05/fix1-junit-summary.txt',
    'EXT-A-MATERIAL-05/reload-commands.txt',
    'EXT-A-MATERIAL-05/reload-evidence.txt',
    'EXT-A-MATERIAL-05/reload-false-true-false-latest.log',
    'EXT-A-MATERIAL-05/external-quartz-pack/pack.mcmeta',
    'EXT-A-MATERIAL-05/external-quartz-pack/data/c/tags/item/dusts/quartz.json',
    'EXT-A-MATERIAL-05/default-run-before.csv',
    'EXT-A-MATERIAL-05/default-run-after.csv',
    'EXT-A-MATERIAL-05/default-run-comparison.txt',
    'EXT-A-MATERIAL-05/java-before.json',
    'EXT-A-MATERIAL-05/java-after-reload.json',
    'EXT-A-MATERIAL-05/java-after.json',
    'EXT-A-MATERIAL-05/root-latest.log.before',
    'EXT-A-MATERIAL-05/root-latest.log.after',
    'EXT-A-MATERIAL-05/root-debug.log.before',
    'EXT-A-MATERIAL-05/root-debug.log.after',
    'EXT-A-MATERIAL-05/pre-fix1-default-run-after.csv',
    'EXT-A-MATERIAL-05/pre-fix1-default-run-comparison.txt',
    'EXT-A-MATERIAL-05/pre-fix1-java-after.json',
    'EXT-A-MATERIAL-05/pre-fix1-root-latest.log.after',
    'EXT-A-MATERIAL-05/pre-fix1-root-debug.log.after',
    'EXT-A-MATERIAL-05/resource-hashes.csv',
    'EXT-A-MATERIAL-05/old-texture-diff.txt',
    'EXT-A-MATERIAL-05/artifact-verification.json',
    'EXT-A-MATERIAL-05/pm-artifact-verification.json',
    'EXT-A-MATERIAL-05/fix1-artifact-verification.json',
    'EXT-A-MATERIAL-05/pm-fix1-artifact-verification.json',
    'EXT-A-MATERIAL-05/fix1-review.diff',
    'EXT-ART-07/preexisting-game-png-sha256.json'
)
$names += @(Get-ChildItem -LiteralPath (Join-Path $report 'junit-xml') -Filter 'TEST-*.xml' -File |
    Sort-Object Name | ForEach-Object { "EXT-A-MATERIAL-05/junit-xml/$($_.Name)" })
$manifest = @($names | ForEach-Object {
    $file = Join-Path $extension $_
    if (-not (Test-Path -LiteralPath $file)) { throw "证据文件缺失: $_" }
    [pscustomobject]@{
        Path = $_
        Length = (Get-Item -LiteralPath $file).Length
        Sha256 = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    }
})
$manifest | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $report 'evidence-manifest.csv')
$names += 'EXT-A-MATERIAL-05/evidence-manifest.csv'

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath = Join-Path $report 'evidence-small.zip'
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath }
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($name in $names) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,
            (Join-Path $extension $name), $name.Replace('\', '/'),
            [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally {
    $zip.Dispose()
}
$hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
"ZIP=evidence-small.zip`nentries=$($names.Count)`nbytes=$((Get-Item -LiteralPath $zipPath).Length)`nsha256=$hash`nmanifest=evidence-manifest.csv" |
    Set-Content -Encoding UTF8 (Join-Path $report 'evidence-index.txt')
