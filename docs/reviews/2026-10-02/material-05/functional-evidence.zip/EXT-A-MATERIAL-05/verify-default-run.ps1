param([string]$ProjectRoot = (Resolve-Path '.').Path)

$ErrorActionPreference = 'Stop'
$report = Join-Path $ProjectRoot 'build/reports/extension/EXT-A-MATERIAL-05'
$runRoot = (Resolve-Path (Join-Path $ProjectRoot 'run')).Path
$before = @(Import-Csv (Join-Path $report 'default-run-before.csv'))
$after = @(Get-ChildItem -LiteralPath $runRoot -Recurse -File -Force | ForEach-Object {
    [pscustomobject]@{
        Path = $_.FullName.Substring($runRoot.Length + 1)
        Length = [string]$_.Length
        Utc = $_.LastWriteTimeUtc.ToString('o')
        Sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    }
})
$after | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $report 'default-run-after.csv')
$different = @(Compare-Object $before $after -Property Path,Length,Utc,Sha256)
if ($different.Count -ne 0) {
    $different | Format-Table -AutoSize | Out-String | Set-Content -Encoding UTF8 (Join-Path $report 'default-run-comparison.txt')
    throw "默认run有 $($different.Count) 项路径/长度/UTC时间/哈希差异"
}
"默认run前后相同：$($before.Count)项；比较路径、长度、UTC时间和SHA-256。" |
    Set-Content -Encoding UTF8 (Join-Path $report 'default-run-comparison.txt')
