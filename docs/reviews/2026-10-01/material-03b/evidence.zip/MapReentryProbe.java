import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.SplittableRandom;

public final class MapReentryProbe {
    private static final class Task implements Runnable {
        final int id;
        final int hash;
        Runnable action = () -> {};

        Task(int id, int hash) {
            this.id = id;
            this.hash = hash;
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @Override
        public void run() {
            action.run();
        }
    }

    public static void main(String[] args) throws Exception {
        Field capacityField = Object2LongOpenHashMap.class.getDeclaredField("n");
        capacityField.setAccessible(true);
        SplittableRandom random = new SplittableRandom(20261001L);

        for (int initialCount = 1; initialCount <= 26; initialCount++) {
            for (int trial = 0; trial < 100000; trial++) {
                Object2LongOpenHashMap<Runnable> map = new Object2LongOpenHashMap<>();
                Task[] initial = new Task[initialCount];
                int[] hashes = new int[initialCount];
                for (int index = 0; index < initialCount; index++) {
                    hashes[index] = random.nextInt(64);
                    initial[index] = new Task(index, hashes[index]);
                }
                Task nested = new Task(initialCount, random.nextInt(64));
                initial[0].action = () -> map.put(nested, 7L);
                for (int index = 0; index < initialCount; index++) {
                    map.put(initial[index], index == 0 ? 5L : 7L);
                }
                int capacityBefore = capacityField.getInt(map);
                StringBuilder visited = new StringBuilder();
                ObjectIterator<Object2LongMap.Entry<Runnable>> iterator = map.object2LongEntrySet().iterator();
                try {
                    while (iterator.hasNext()) {
                        Object2LongMap.Entry<Runnable> entry = iterator.next();
                        Task current = (Task) entry.getKey();
                        visited.append(current.id).append('@').append(entry.getLongValue()).append(',');
                        if (entry.getLongValue() <= 5L) {
                            current.run();
                            iterator.remove();
                        }
                    }
                } catch (NullPointerException failure) {
                    System.out.printf("NPE initialCount=%d trial=%d capacityBefore=%d capacityAfter=%d hashes=%s nestedHash=%d visited=%s sizeAfter=%d%n",
                            initialCount, trial, capacityBefore, capacityField.getInt(map), Arrays.toString(hashes),
                            nested.hash, visited, map.size());
                    failure.printStackTrace(System.out);
                    return;
                }
            }
            System.out.printf("SEARCHED initialCount=%d trials=100000%n", initialCount);
        }
        System.out.println("NO_NPE_FOUND");
    }
}
