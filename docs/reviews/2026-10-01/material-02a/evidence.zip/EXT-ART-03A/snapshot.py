import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,r'E:\MyMC\NewMod\Create_NuclearIndustry-ore-acquisition\tools\art-assets')
import pipeline
root=Path(r'E:\MyMC\NewMod\Create_NuclearIndustry-ore-acquisition')
ev=root/'build/reports/extension/EXT-ART-03A'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=['tools/art-assets/manifest.json','tools/art-assets/palette.json','tools/art-assets/baseline.json','tools/art-assets/verify.py','tools/art-assets/pipeline.py','tools/art-assets/export.py']
protected_hashes={p:h(root/p) for p in protected}
legacy={p:h(pipeline.GAME_ROOT/p) for p in sorted(pipeline.GAME_FILES)}
other_previews={p.relative_to(root).as_posix():h(p) for p in sorted((root/'tools/art-assets/previews').glob('*.png')) if p.name not in ('items-1.png','items-2.png')}
json.dump({'commit':'0d38c99fe8d3e041c6148057fc4f62827b9e45b4','protected_sha256':protected_hashes,'legacy_51_game_png_sha256':legacy,'legacy_game_paths':sorted(legacy),'other_preview_png_sha256':other_previews,'initial_game_png_path_count':len(list(pipeline.GAME_ROOT.rglob('*.png')))},open(ev/'pre-change-evidence.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)
