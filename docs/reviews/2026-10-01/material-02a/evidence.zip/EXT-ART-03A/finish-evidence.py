import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,r'E:\MyMC\NewMod\Create_NuclearIndustry-ore-acquisition\tools\art-assets')
from PIL import Image,ImageDraw,ImageFont
import pipeline
from export import read_palette,render_svg
root=Path(r'E:\MyMC\NewMod\Create_NuclearIndustry-ore-acquisition');ev=root/'build/reports/extension/EXT-ART-03A';art=root/'tools/art-assets';src=art/'sources/item';game=root/'src/main/resources/assets/create_nuclear_industry/textures/item';gen=art/'generated/item';pal=read_palette();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
board=Image.new('RGBA',(620,350),'#17212a');d=ImageDraw.Draw(board);font=ImageFont.load_default(size=17);small=ImageFont.load_default(size=14)
records={}
for idx,name in enumerate(('lead_plate','tin_plate')):
 y=18+idx*160;colors={c.upper() for c in pal[name].values()}
 old=render_svg((ev/f'{name}.before.svg').read_text(encoding='utf-8-sig'),colors);new=render_svg((src/f'{name}.svg').read_text(encoding='utf-8-sig'),colors)
 d.text((24,y),name,font=font,fill='#e3ece8')
 for im,label,x in ((old,'BEFORE',24),(new,'AFTER',330)):
  d.text((x,y+24),label,font=small,fill='#a6b9c2');tile=Image.new('RGBA',(112,112),'#d8d9d4');tile.alpha_composite(im.resize((112,112),Image.Resampling.NEAREST));board.alpha_composite(tile,(x,y+44))
 d.line((24,y+158,596,y+158),fill='#40515c',width=1)
 with Image.open(gen/f'{name}.png') as im:
  pix=im.convert('RGBA');alpha=pix.getchannel('A');box=alpha.getbbox();colors_out={tuple(c[:3]) for c in pix.get_flattened_data() if c[3]}
  records[name]={'source_sha256':h(src/f'{name}.svg'),'generated_sha256':h(gen/f'{name}.png'),'installed_sha256':h(game/f'{name}.png'),'size':list(pix.size),'opaque_bounds_xyxy':list(box),'opaque_width':box[2]-box[0],'opaque_height':box[3]-box[1],'width_height_ratio':round((box[2]-box[0])/(box[3]-box[1]),4),'opaque_colors':len(colors_out),'alpha_values':sorted(set(alpha.get_flattened_data())),'outer_border_transparent':all(alpha.getpixel((x,y))==0 for x,y in [(0,i) for i in range(16)]+[(15,i) for i in range(16)]+[(i,0) for i in range(16)]+[(i,15) for i in range(16)]),'svg_generated_game_pixels_equal':pix.tobytes()==new.tobytes()}
board.convert('RGB').save(ev/'comparison.png')
pre=json.load(open(ev/'pre-change-evidence.json',encoding='utf-8'));post_protected={p:h(root/p) for p in pre['protected_sha256']};post_old={p:h(pipeline.GAME_ROOT/p) for p in sorted(pipeline.GAME_FILES)};post_previews={p.relative_to(root).as_posix():h(p) for p in sorted((art/'previews').glob('*.png')) if p.name not in ('items-1.png','items-2.png')};paths={p.relative_to(pipeline.GAME_ROOT).as_posix() for p in pipeline.GAME_ROOT.rglob('*.png')}
state={'protected_files_unchanged':post_protected==pre['protected_sha256'],'legacy_51_game_pngs_unchanged':post_old==pre['legacy_51_game_png_sha256'],'legacy_path_count':len(pipeline.GAME_FILES),'new_game_path_count':len(paths),'game_paths_match_53':paths==pipeline.ALLOWED_GAME_FILES,'other_group_previews_unchanged':post_previews==pre['other_preview_png_sha256'],'generated_game_pngs':records,'preview_sha256':{p:h(art/p) for p in ['preview.png','preview.html','previews/items-1.png','previews/items-2.png']},'comparison_sha256':h(ev/'comparison.png')}
json.dump(state,open(ev/'final-evidence.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)
print(json.dumps(state,ensure_ascii=False,indent=2))

