"""离线核对历史贴图及EXT-ART-03新增板材：原冷却剂保留、SVG像素、复现性和失败不写出。

只在显式执行本脚本时做临时坏输入实验，finally 原样恢复源稿/清单。
不调用游戏、Gradle 或 Git 写操作；结果保存在本任务证据目录。
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter

sys.dont_write_bytecode=True
ROOT_ART=Path(r'E:\MyMC\NewMod\Create_NuclearIndustry-ore-acquisition\tools\art-assets')
sys.path.insert(0,str(ROOT_ART))
from PIL import Image, ImageDraw, __version__ as pillow_version
import pipeline
from export import render_svg, read_palette, ROOT

REPO=ROOT.parents[1]
EVIDENCE=REPO/'build/reports/extension/EXT-ART-03A'
EVIDENCE.mkdir(parents=True,exist_ok=True)
ENV=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
log=[]
# 用户只撤回两种冷却剂的八条路径；独立列举，避免随管线白名单错误一起放宽。
RETAINED_COOLANTS=frozenset(f'{directory}/{name}_{state}.png'
    for directory in ('block','fluid')
    for name in ('compound_coolant','hot_compound_coolant')
    for state in ('still','flow'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args,good=True):
    """保留真实子进程命令和退出码；失败检查不得只调用内部解析函数。"""
    command=[sys.executable,str(ROOT/'export.py'),*args]
    result=subprocess.run(command,cwd=REPO,env=ENV,text=True,encoding='utf-8',capture_output=True)
    log.append({'command':command,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    assert (result.returncode==0)==good,result.stderr


def state():
    """记录候选、全部预览、游戏路径的字节；失败实验不允许改变其中任何一项。"""
    paths=list((ROOT/'generated').rglob('*.png'))+list((ROOT/'previews').glob('*.png'))+[ROOT/'preview.html',ROOT/'preview.png']+list(pipeline.GAME_ROOT.rglob('*.png'))
    return {p.relative_to(REPO).as_posix():digest(p) for p in sorted(paths)}


entries,images,before,retained=pipeline.prepare();palette=read_palette()
baseline=json.loads((ROOT/'baseline.json').read_text(encoding='utf-8'))
assert {r['game'] for r in baseline['records']}==pipeline.GAME_FILES
assert len(baseline['records'])==51
assert len(entries)==54
assert Counter(tuple(e['size']) for e in entries if e['game'])=={(16,16):49,(16,64):4}
results={'python':sys.version,'pillow':pillow_version,'baseline':baseline['head'],'historical_game_count':51,'new_game_count':2,'source_count':len({e['source'] for e in entries}),'records':[]}
for e in entries:
    name=e['game'] or 'item/lapis_dust.png'
    if name in RETAINED_COOLANTS:
        original=subprocess.check_output(['git','show',f'eddd097^:src/main/resources/assets/create_nuclear_industry/textures/{name}'],cwd=REPO)
        assert (ROOT/'generated'/name).read_bytes()==original==(ROOT/'baseline'/name).read_bytes(),f'冷却剂必须逐字节保留原图: {name}'
        with Image.open(ROOT/'generated'/name) as output:
            pipeline.validate_alpha(e,output)
            assert output.tobytes()==images[name].tobytes()
        results['records'].append({'game':name,'size':e['size'],'retained_original_sha256':hashlib.sha256(original).hexdigest()})
        continue
    source=ROOT/'sources'/e['source']
    # 独立使用 Pillow 矩形 API，核对导出器手动覆盖像素的坐标和边界。
    reference=Image.new('RGBA',tuple(e['size']));draw=ImageDraw.Draw(reference)
    for rect in ET.parse(source).getroot():
        x,y,w,h=[int(rect.get(k)) for k in ('x','y','width','height')]
        draw.rectangle((x,y,x+w-1,y+h-1),fill=rect.get('fill'))
    with Image.open(ROOT/'generated'/name) as output:
        assert output.mode=='RGBA' and list(output.size)==e['size']
        assert output.tobytes()==reference.tobytes()==images[name].tobytes(),name
        pipeline.validate_alpha(e,output)
        colors={p[:3] for p in output.get_flattened_data() if p[3]}
        allowed={tuple(int(c[i:i+2],16) for i in (1,3,5)) for c in palette[e['palette']].values()}
        assert colors<=allowed and len(colors)<=16
    results['records'].append({'game':e['game'],'source':e['source'],'size':e['size'],'colors':len(colors),'generated_sha256':digest(ROOT/'generated'/name),'use':e['use']})
    if e['game'] in pipeline.GAME_FILES:
        record=next(r for r in baseline['records'] if r['game']==name)
        assert digest(ROOT/'baseline'/name)==record['sha256'],'旧图证据改变'
    elif e['game'] in pipeline.NEW_GAME_FILES:
        results['records'][-1]['historical_baseline']='none; explicitly new candidate'

# 已批准四样稿使用工具基线的原始字节作独立回归依据，不以新导出互相比较。
for name in ('item/lapis_dust','item/lead_ingot','item/steel_plate','block/lead_ore'):
    for directory,suffix in (('sources','.svg'),('generated','.png')):
        rel=f'tools/art-assets/{directory}/{name}{suffix}'
        original=subprocess.check_output(['git','show',f'49e6c86:{rel}'],cwd=REPO)
        current=(REPO/rel).read_bytes()
        # Git 工作树可能启用 CRLF；SVG 只归一化行尾，PNG 仍逐字节比较。
        if suffix=='.svg':current=current.replace(b'\r\n',b'\n');original=original.replace(b'\r\n',b'\n')
        assert current==original,f'已批准样稿被改变: {rel}'
results['approved_pilot_unchanged']=True

# 显式接入后逐条核对：旧51张图保持当前字节，两张新路径与导出候选一致。
historical_before={name:digest(pipeline.GAME_ROOT/name) for name in pipeline.GAME_FILES}
run('--install')
assert {p.relative_to(pipeline.GAME_ROOT).as_posix() for p in pipeline.GAME_ROOT.rglob('*.png')}==pipeline.ALLOWED_GAME_FILES
for e in entries:
    if e['game']:
        assert (pipeline.GAME_ROOT/e['game']).read_bytes()==(ROOT/'generated'/e['game']).read_bytes()
        if e['game'] in pipeline.NEW_GAME_FILES:
            assert not (ROOT/'baseline'/e['game']).exists(),'新增图不得伪造旧基线'
        elif e['game'] in RETAINED_COOLANTS:
            assert (pipeline.GAME_ROOT/e['game']).read_bytes()==(ROOT/'baseline'/e['game']).read_bytes(),'旧冷却剂被再次覆盖'
assert {name:digest(pipeline.GAME_ROOT/name) for name in pipeline.GAME_FILES}==historical_before,'原51张游戏PNG被改动'
after=state();run('--install');assert state()==after
results['install_repeat_exports']=2
results['historical_51_game_png_unchanged']=True
results['svg_or_retained_original_generated_game_equal']=True
results['output_hashes']=after
results['result']='PASS'
(EVIDENCE/'verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(EVIDENCE/'commands.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in results.items() if k not in ('records','output_hashes','invalid_svg_rejected')},ensure_ascii=True,indent=2))

