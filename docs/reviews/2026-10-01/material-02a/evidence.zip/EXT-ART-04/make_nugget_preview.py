from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[4]
out = root / 'build/reports/extension/EXT-ART-04/nugget-preview.png'
canvas = Image.new('RGBA', (1160, 570), '#17212A')
draw = ImageDraw.Draw(canvas)
font = ImageFont.load_default(size=20)
small = ImageFont.load_default(size=15)
draw.text((24, 18), 'EXT-ART-04 / METAL NUGGETS / PIXEL-SCALE COMPARISON', font=font, fill='#E3ECE8')
columns = [('NUGGET', 'nugget'), ('INGOT', 'ingot'), ('RAW ORE', 'raw'), ('PLATE', 'plate')]
for col, (label, _) in enumerate(columns):
    draw.text((218 + col * 228, 58), label, font=small, fill='#A6B9C2')
for row, metal in enumerate(('lead', 'tin')):
    y = 92 + row * 228
    draw.text((24, y + 10), metal.upper(), font=font, fill='#E3ECE8')
    for col, (_, kind) in enumerate(columns):
        x = 112 + col * 228
        draw.rounded_rectangle((x, y, x + 204, y + 204), radius=4, fill='#25323D')
        name = f'raw_{metal}' if kind == 'raw' else f'{metal}_{kind}'
        path = root / 'tools/art-assets/generated/item' / f'{name}.png'
        if kind == 'plate':
            path = root / 'src/main/resources/assets/create_nuclear_industry/textures/item' / f'{name}.png'
        with Image.open(path) as source:
            image = source.convert('RGBA').resize((128, 128), Image.Resampling.NEAREST)
        checker = Image.new('RGBA', image.size, '#E5E2D9')
        checker.alpha_composite(image)
        canvas.alpha_composite(checker, (x + 38, y + 38))
        draw.text((x + 12, y + 174), '16×16 · nearest neighbour', font=small, fill='#A6B9C2')
canvas.convert('RGB').save(out, format='PNG', optimize=False, compress_level=9)
print(out)



