"""独立核对 EXT-ART-04 开工时53张游戏图在本批之后逐字节未变。"""
import hashlib
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[4]
snapshot_path = Path(__file__).with_name('pre-existing-53-game-png-hashes.json')
snapshot = json.loads(snapshot_path.read_text(encoding='utf-8'))
textures = repo / 'src/main/resources/assets/create_nuclear_industry/textures'
assert len(snapshot) == 53
records = {}
for row in snapshot:
    path = repo / row['path']
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == row['sha256'], f"开工前文件字节变化：{row['path']}"
    records[row['path']] = actual
assert len(list(textures.rglob('*.png'))) == 55
result = {
    'result': 'PASS',
    'pre_existing_paths': len(records),
    'final_game_paths': 55,
    'plate_hashes': {
        name: records[f'src/main/resources/assets/create_nuclear_industry/textures/item/{name}.png']
        for name in ('lead_plate', 'tin_plate')
    },
}
Path(__file__).with_name('pre-existing-snapshot-check.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8'
)
print(json.dumps(result, ensure_ascii=False, indent=2))
