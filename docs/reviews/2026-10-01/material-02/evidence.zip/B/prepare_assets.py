import json
from pathlib import Path
root = Path('tools/art-assets')
palpath=root/'palette.json'
pal=json.loads(palpath.read_text(encoding='utf-8'))
pal['lead_plate']={'outline':'#303441','shadow':'#464C5D','side':'#60687A','body':'#7E8798','light':'#A6AFBF','glint':'#CDD3DE'}
pal['tin_plate']={'outline':'#354249','shadow':'#556875','side':'#8AA4B1','body':'#B9CED5','light':'#E2E9DE','glint':'#F2F1E6'}
palpath.write_text(json.dumps(pal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
mpath=root/'manifest.json'
man=json.loads(mpath.read_text(encoding='utf-8'))
for name in ('lead_plate','tin_plate'):
    man['entries'].append({'game':f'item/{name}.png','source':f'item/{name}.svg','palette':name,'size':[16,16],'kind':'item','group':'items','use':'EXT-ART-03 \u65b0\u589e\u8def\u5f84\uff1b\u65e0\u65e7\u56fe\u57fa\u7ebf'})
man['entries'].sort(key=lambda e:(e['game'] is None,e['game'] or ''))
mpath.write_text(json.dumps(man,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def draw(name,rows,colors):
    lines=['<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" shape-rendering="crispEdges">']
    for y,row in enumerate(rows):
        x=0
        while x<len(row):
            c=row[x]
            if c=='.': x+=1; continue
            end=x+1
            while end<len(row) and row[end]==c: end+=1
            lines.append(f'  <rect x="{x}" y="{y}" width="{end-x}" height="1" fill="{colors[c]}"/>')
            x=end
    lines.append('</svg>')
    (root/'sources/item'/f'{name}.svg').write_text('\n'.join(lines)+'\n',encoding='utf-8')
lead=['................','................','................','....OOOOOOOO....','..OOggggggOO....','.OglbbbbbbboO...','OglbbbbbbbbboO..','OllbbbbbbbsssoO.','OlsbbbbbbsssoO..','.OssssssssssO...','..OOOOOOOOOO....','................','................','................','................','................']
lead_colors={'O':'#303441','o':'#303441','g':'#CDD3DE','l':'#A6AFBF','b':'#7E8798','s':'#60687A'}
tin=['................','................','................','...OOOOOOOOOO...','..OOggggggggOO..','.OglbbbbbbbbboO.','OglbbbbbbbbbbboO','OllbbbbbbbbsssoO','OlsbbbbbbbsssoO.','.OssssssssssOO..','..OOOOOOOOOO....','................','................','................','................','................']
tin_colors={'O':'#354249','o':'#556875','g':'#F2F1E6','l':'#E2E9DE','b':'#B9CED5','s':'#8AA4B1'}
draw('lead_plate',lead,lead_colors)
draw('tin_plate',tin,tin_colors)
