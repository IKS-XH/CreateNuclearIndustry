from pathlib import Path
root=Path('tools/art-assets')
def draw(name,rows,colors):
    rows=['.'+r[1:15]+'.' for r in rows]
    lines=['<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" shape-rendering="crispEdges">']
    for y,row in enumerate(rows):
        x=0
        while x<len(row):
            c=row[x]
            if c=='.': x+=1; continue
            end=x+1
            while end<len(row) and row[end]==c: end+=1
            lines.append(f'  <rect x="{x}" y="{y}" width="{end-x}" height="1" fill="{colors[c]}"/>')
            x=end
    lines.append('</svg>')
    (root/'sources/item'/f'{name}.svg').write_text('\n'.join(lines)+'\n',encoding='utf-8')
lead=['................','................','................','....OOOOOOOO....','..OOggggggOO....','.OglbbbbbbboO...','OglbbbbbbbbboO..','OllbbbbbbbsssoO.','OlsbbbbbbsssoO..','.OssssssssssO...','..OOOOOOOOOO....','................','................','................','................','................']
lead_colors={'O':'#303441','o':'#303441','g':'#CDD3DE','l':'#A6AFBF','b':'#7E8798','s':'#60687A'}
tin=['................','................','................','...OOOOOOOOOO...','..OOggggggggOO..','.OglbbbbbbbbboO.','OglbbbbbbbbbbboO','OllbbbbbbbbsssoO','OlsbbbbbbbsssoO.','.OssssssssssOO..','..OOOOOOOOOO....','................','................','................','................','................']
tin_colors={'O':'#354249','o':'#556875','g':'#F2F1E6','l':'#E2E9DE','b':'#B9CED5','s':'#8AA4B1'}
draw('lead_plate',lead,lead_colors);draw('tin_plate',tin,tin_colors)
