from pathlib import Path
p=Path('tools/art-assets/README.md')
s=p.read_text(encoding='utf-8').replace('其余46张用于45张游戏重绘、铅板/锡板新增路径和青金石粉候选。','其余46张用于43张历史游戏图重绘、2张新增板材和青金石粉候选。')
p.write_text(s,encoding='utf-8')
