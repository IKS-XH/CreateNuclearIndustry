import json
from pathlib import Path
p=Path('tools/art-assets/manifest.json')
d=json.loads(p.read_text(encoding='utf-8'))
seen=set(); out=[]
for e in d['entries']:
    if e.get('game') in ('item/lead_plate.png','item/tin_plate.png'):
        if e['game'] in seen: continue
        seen.add(e['game'])
    out.append(e)
d['entries']=out
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert len(out)==54 and seen=={'item/lead_plate.png','item/tin_plate.png'}
