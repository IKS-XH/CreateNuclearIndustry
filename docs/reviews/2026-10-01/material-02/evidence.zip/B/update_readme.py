from pathlib import Path
p=Path('tools/art-assets/README.md')
s=p.read_text(encoding='utf-8')
s=s.replace('显式覆盖固定51个已有PNG，拒绝新路径或尺寸变更。','显式覆盖原51个已有PNG并允许恰好两条 EXT-ART-03 板材新路径；其他新增路径或尺寸变更均拒绝。')
s=s.replace('`manifest.json`：52 条显式记录，列出游戏相对路径、SVG、色板、尺寸、透明合同、分组与基线用途。51条对应游戏路径，lapis 条目的 game 为 null；仅8项冷却剂必须声明 `preserve: baseline-original`，其他项禁止此字段。','`manifest.json`：54 条显式记录，列出游戏相对路径、SVG、色板、尺寸、透明合同、分组与基线用途。53条对应游戏路径（历史51条加铅板/锡板两条），lapis 条目的 game 为 null；仅8项冷却剂必须声明 `preserve: baseline-original`，其他项禁止此字段。')
s=s.replace('`pipeline.py`：独立硬编码51路径白名单，不由 manifest 任意扩展写集；严格校验映射和尺寸后才准备输出。','`pipeline.py`：独立硬编码原51路径白名单，并单独列出 `item/lead_plate.png` 与 `item/tin_plate.png` 两条扩展；不由 manifest 任意扩展写集。严格校验映射、尺寸后才准备输出；旧 `baseline/` 与 `baseline.json` 仍恰为51条。')
s=s.replace('`generated/`：52 个导出候选；47个16×16游戏图、4个16×64游戏flow、1个16×16工具候选。','`generated/`：54 个导出候选；49个16×16游戏图、4个16×64游戏flow、1个16×16工具候选。两张新增板材在预览中标为 NEW，不生成历史对照图或基线记录。')
s=s.replace('EXT-ART-02A 覆盖：51路径/尺寸不变、8项冷却剂与重绘前 Git/原图证据字节相同、其余 SVG→独立矩形参考→候选PNG→游戏PNG一致、四样稿回归（SVG只归一化Git行尾，PNG逐字节）、30类非法SVG/长画布越界拒绝、6种实际CLI失败不改变输出、两次默认导出与两次显式接入哈希一致。','EXT-ART-02A 原验证覆盖：历史51路径/尺寸不变、8项冷却剂与重绘前 Git/原图证据字节相同、其余 SVG→独立矩形参考→候选PNG→游戏PNG一致、四样稿回归（SVG只归一化Git行尾，PNG逐字节）、30类非法SVG/长画布越界拒绝、6种实际CLI失败不改变输出、两次默认导出与两次显式接入哈希一致。EXT-ART-03 增加两条独立白名单路径；旧51基线和既有游戏图仍逐字节核对，新板材没有旧图记录，不得伪造历史基线。')
p.write_text(s,encoding='utf-8')
